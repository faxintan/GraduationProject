// 异步实现数据库操作
import mongoose from 'mongoose'

const Schema = mongoose.Schema
const ObjectId = Schema.Types.ObjectId

var userSchema = new Schema({
    account: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    name: {
        type: String,
        required: true,
        unique: true
    },
    position: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    registed: {
        type: Date,
        default: Date.now
    },
    extendInfo: {
        type: Boolean,
        default: false
    },
    school: {
        type: String
    },
    faculty: {
        type: String
    },
    nativePlace: {
        type: String
    },
    IdCard: {
        type: String
    },
    age: {
        type: Number
    },
    sexual: {
        type: String
    },
    address: {
        type: String
    },
    beginDate: {
        type: String
    },
    endDate: {
        type: String
    },
    briefIntro: {
        type: String
    },
    award: {
        type: String
    },
    education: {
        type: String
    },
    major: {
        type: ObjectId
    },
    courses: [{
        _id: ObjectId,
        name: String,
        intro: String,
        field: String,
        score: Number,
        credit: Number,
        beginDate: String,
        endDate: String
    }]
})

export default mongoose.model('User', userSchema)

// userSchema.statics.create = async function (obj) {
//     const user = new this(obj)
//     const exists = await this.findOne({name: obj.name})
//     if (exists) {
//         console.log('fait to create, the user exists !!! ')
//         return
//     }
//     const back = await user.save()
//     if (back) {
//         console.log(`the user ${back.name} have been created`)
//     }
// }

// userSchema.static.findById = async function (_id) {
//     const exist = await this.findById(_id)
//     if (exist) {
//         console.log('info: ' + exist)
//     } else {
//         console.log('no this user')
//     }
// }

// userSchema.statics.findByName = async function (name) {
//     const exist = await this.findOne({name: name})
//     if (exist) {
//         // console.log('info: ' + exist)
//         return exist
//     } else {
//         console.log('no this user')
//     }
// }