import mongoose from 'mongoose'

const Schema = mongoose.Schema
const ObjectId = Schema.Types.ObjectId

var mojorSchema = new Schema({
    name: {
        type: String,
        required: true,
        unique: true
    },
    intro: {
        type: String,
        required: true
    },
    subject: {
        type: String,
        required: true
    },
    score: {
        type: Number,
        required: true
    },
    phone: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    registed: {
        type: Date,
        default: Date.now
    },
    teacher: {
        type: ObjectId,
        required: true
    },
    students: [{
        studentId: ObjectId,
        name: String
    }],
    courses: [{
        courseId: ObjectId,
        name: String
    }]
})

export default mongoose.model('Major', mojorSchema)