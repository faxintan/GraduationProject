export default {
    port: process.env.PORT || 3000,
    mongodbUrl: 'mongodb://localhost:27017/test'
}