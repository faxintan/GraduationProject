import Koa from 'koa'
import Router from 'koa-router'
import mount from 'koa-mount'
import favicon from 'koa-favicon'
import json from 'koa-json'
import logger from 'koa-logger'
import bodyparser from 'koa-bodyparser'
import jwt from 'koa-jwt'
import entry from 'koa-static'
import path from 'path'
import mongoose from 'mongoose'
import config from './config'
import apiEntry from './routes/'

// MongoDB 操作
var db = mongoose.connect(config.mongodbUrl)
db.connection.on('error', err => {
    console.log('connect mongodb failed !!! ', err)
})
db.connection.once('open', () => {
    console.log('connect mongodb success')
})

// Koa 操作
const app = new Koa()

app.use(favicon(path.resolve(__dirname, '../favicon.ico')))
app.use(entry(path.resolve(__dirname, '../dist')))
app.use(bodyparser())
app.use(json())
app.use(logger())

app.use(async function (ctx, next) {
    let start = new Date
    try {
        await next()
    } catch (err) {
        if (401 === err.status) {
            ctx.body = {status: 'failure', result: '请用户先登录'}
        } else {
            ctx.body = err
        }
    }
    let ms = new Date - start
    console.log('%s %s - %s', ctx.method, ctx.url, ms)
})

// 为koa-router注册规则，并挂载在koa上(添加认证)
// app.use(jwt({secret: 'Louis&Bunny'}).unless({path: [/^\/auth*/]}))
app.use(apiEntry.routes())

app.on('error', (err, ctx) => {
    console.log('server error', err)
})

app.listen(config.port, () => {
    console.log(`Koa is listening in ${config.port} ... `)
})

export default app