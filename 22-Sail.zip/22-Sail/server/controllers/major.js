import Major from '../models/major.js'

function setResponse (status, result, msg) {
    return {status: status, result: result, msg: msg}
}

async function getMajorList (ctx, next) {
    try {
        const result = await Major.find()
        if (result.length) {
            ctx.body = setResponse('success', result)
        } else {
            ctx.body = setResponse('success', result, '专业列表为空')
        }
    } catch (err) {
        ctx.body = setResponse('failure', null, '获取专业列表失败')
    }
}

async function getMajorById (ctx, next) {
    try {
        const result = await Major.findOne({_id: ctx.params.id})
        if (result) {
            ctx.body = setResponse('success', result)
        } else {
            ctx.body = setResponse('failure', '该专业不存在')
        }
    } catch (err) {
        ctx.body = setResponse('failure', '系统异常...')
    }
}

async function createMajor (ctx, next) {
    const majorInfo = ctx.request.body
    const exist = await Major.findOne({name: majorInfo.name})
    if (exist) {
        ctx.body = setResponse('failure', exist.name + '专业已创建')
    } else {
        try {
            const result = await new Major(majorInfo).save()
            ctx.body = setResponse('success', result, result.name + '专业创建成功')
        } catch (err) {
            let errStr = ''
            for (let prop in err.errors) {
                errStr += prop + ', '
            }
            errStr += '数据验证失败'
            ctx.body = setResponse('failure', errStr, '创建失败,请填写真确数据')
        }
    }
}

async function updateMajor (ctx, next) {
    const majorInfo = ctx.request.body
    try {
        const result = await Major.findByIdAndUpdate({_id: majorInfo._id}, majorInfo, {new: true})
        if (result && result._id) {
            ctx.body = setResponse('success', result, result.name + ' 专业信息更新成功')
        } else {
            ctx.body = setResponse('failure', majorInfo.name + ' 专业信息更新失败')
        }
    } catch (err) {
        ctx.body = setResponse('failure', '系统异常...', '更新失败')
    }
}

async function deleteMajor (ctx, next) {
    try {
        let result = await Major.findByIdAndRemove({_id: ctx.params.id}, {select: {name: true}})
        if (typeof result.name === 'string') {
            ctx.body = setResponse('success', null, result.name + ' 专业信息删除成功')
        } else {
            ctx.body = setResponse('failure', '删除失败')
        }
    } catch (err) {
        ctx.body = setResponse('failure', err.name)
    }
}

async function deleteMajorList (ctx, next) {
    try {
        await Major.remove({_id: {$in: ctx.request.body}})
        ctx.body = setResponse('success', null, '删除成功')
    } catch (err) {
        ctx.body = setResponse('failure', null, '删除失败')
    }
}

export default {
    route: (router) => {
        router.get('/major/:id', getMajorById)
              .post('/major', createMajor)
              .put('/major', updateMajor)
              .del('/major/:id', deleteMajor)
              .get('/majorList', getMajorList)
              .post('/majorList', deleteMajorList)
    }
}