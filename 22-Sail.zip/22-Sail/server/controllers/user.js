import jwt from 'koa-jwt'
import User from '../models/user.js'

// msg为请求响应提示，不赋值则没有提示
// 成功时提示，错误时交由前端进行后续处理
function setResponse (status, result, msg) {
    return {status: status, result: result, msg: msg}
}

async function loginAuth (ctx, next) {
    const {account, password} = ctx.request.body
    try {
        const result = await User.findOne({account: account})
        if (result) {
            if (result.password === password) {
                const userToken = {user: result}
                const secret = 'Louis&Bunny'
                const token = jwt.sign(userToken, secret)
                ctx.body = setResponse('success', token)
            } else {
                ctx.body = setResponse('failure', '输入密码错误')
            }
        } else {
            ctx.body = setResponse('failure', account + ' 账号不存在')
        }        
    } catch (err) {
        ctx.body = setResponse('failure', '系统异常，请重新登录')
    }
}

async function getUserById (ctx, next) {
    try {
        const result = await User.findById({_id: ctx.params.id})
        if (result && result._id) {
            ctx.body = setResponse('success', result)
        } else {
            ctx.body = setResponse('failure', '用户不存在')
        }
    } catch (err) {
        ctx.body = setResponse('failure', '系统异常...')
    }
}

async function getUserList (ctx, next) {
    let result = ctx.params.position
    try {
        if (result === 'teacher' || result === 'student') {
            result = await User.find({position: ctx.params.position}, {_id: 1, name: 1})
        } else {
            result = await User.find({}, {_id: 1, name: 1, account: 1, password: 1, position: 1, phone: 1, email: 1, briefIntro: 1, courses: 1})
        }
        if (result && result.length) {
            ctx.body = setResponse('success', result)
        } else {
            ctx.body = setResponse('failure', '用户列表为空')
        }
    } catch (err) {
        ctx.body = setResponse('failure', '系统异常...')
    }
}

async function createUser (ctx, next) {
    const userInfo = ctx.request.body
    const exist = await User.findOne({$or: [{account: userInfo.account}, {name: userInfo.name}]})
    if (exist) {
        ctx.body = setResponse('failure', null, '创建失败，该账号或姓名用户已存在')
    } else {
        try {
            const result = await new User(userInfo).save()
            ctx.body = setResponse('success', result, result.account + ' 账号创建成功')
        } catch (err) {
            let errStr = ''
            for (let prop in err.errors) {
                errStr += prop + ', '
            }
            errStr += '数据验证失败'
            ctx.body = setResponse('failure', errStr, '账号创建失败，请填写正确数据')
        }
    }
}

async function updateUser (ctx, next) {
    let userInfo = ctx.request.body
    delete userInfo.courses
    try {
        const result = await User.findByIdAndUpdate({_id: userInfo._id}, userInfo, {new: true})
        if (result) {
            ctx.body = setResponse('success', result, '用户信息更新成功')
        }
    } catch (err) {
        ctx.body = setResponse('failure', null, '用户信息更新失败')
    }
}

async function deleteUser (ctx, next) {
    try {
        let result = await User.findByIdAndRemove({_id: ctx.params.id}, {select: {name: true}})
        if (typeof result.name === 'string') {
            ctx.body = setResponse('success', null, result.name + ' 用户已删除')
        } else {
            ctx.body = setResponse('failure', null, '删除失败')
        }
    } catch (err) {
        ctx.body = setResponse('failure', err.name, '删除失败')
    }
}

async function deleteUserList (ctx, next) {
    try {
        await User.remove({_id: {$in: ctx.request.body}})
        ctx.body = setResponse('success', null, '删除成功')
    } catch (err) {
        ctx.body = setResponse('failure', null, '删除失败')
    }
}

export default {
    route: (router) => {
        router.post('/auth', loginAuth)
              .get('/user/:id', getUserById)
              .post('/user', createUser)
              .put('/user', updateUser)
              .del('/user/:id', deleteUser)
              .get('/userList/:position', getUserList)
              .post('/userList', deleteUserList)
    }
}