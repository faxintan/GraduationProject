import News from '../models/news.js'

function setResponse (status, result, msg) {
    return {status: status, result: result, msg: msg}
}

async function getNewsList (ctx, next) {
    try {
        const result = await News.find({}, {title: 1, type: 1, content: 1, date: 1}, {limit: 50, sort: {date: -1}})
        ctx.body = setResponse('success', result)
    } catch (err) {
        ctx.body = setResponse('failure', null, '获取消息列表失败')
    }
}

async function createNews (ctx, next) {
    const newsInfo = ctx.request.body
    try {
        const result = await new News(newsInfo).save()
        ctx.body = setResponse('success', result, result.title + ' 消息添加成功')
    } catch (err) {
        let errStr = ''
        for (let prop in err.errors) {
            errStr += prop + ', '
        }
        errStr += '数据验证失败'
        ctx.body = setResponse('failure', errStr)
    }
}

export default {
    route: (router) => {
        router.get('/news', getNewsList)
              .post('/news', createNews)
    }
}