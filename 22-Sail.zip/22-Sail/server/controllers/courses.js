import Course from '../models/course.js'
import User from '../models/user.js'

function setResponse (status, result, msg) {
    return {status: status, result: result, msg: msg}
}

async function getCourseList (ctx, next) {
    try {
        const result = await Course.find()
        if (result.length) {
            ctx.body = setResponse('success', result)
        } else {
            ctx.body = setResponse('success', result, '课程列表为空')
        }
    } catch (err) {
        ctx.body = setResponse('failure', '系统异常...', '获取课程列表失败')
    }
}

async function getCourseById (ctx, next) {
    try {
        const result = await Course.findById({_id: ctx.params.id})
        if (result && result._id) {
            ctx.body = setResponse('success', result)
        } else {
            ctx.body = setResponse('failure', '该课程不存在')
        }
    } catch (err) {
        ctx.body = setResponse('failure', '系统异常...')
    }
}

async function createCourse (ctx, next) {
    const courseInfo = ctx.request.body
    const exist = await Course.findOne({name: courseInfo.name})
    if (exist) {
        ctx.body = setResponse('failure', exist.name + ' 课程已创建')
    } else {
        try {
            const result = await new Course(courseInfo).save()
            try {
                const teacher = await User.findByIdAndUpdate({_id: courseInfo.teacher._id}, {$addToSet: {courses: result}})
                ctx.body = setResponse('success', result)
            } catch (e) {
                ctx.body = setResponse('failure', '系统异常...', '添加任课老师失败')
            }
        } catch (err) {
            let errStr = ''
            for (let prop in err.errors) {
                errStr += prop + ', '
            }
            errStr += '数据验证失败！！！'
            ctx.body = setResponse('failure', errStr, '请填写正确数据')
        }
    }
}

async function updateCourse (ctx, next) {
    let courseInfo = ctx.request.body
    delete courseInfo.students
    try{
        const result = await Course.findByIdAndUpdate({_id: courseInfo._id}, courseInfo, {new: false})
        if (result && result._id) {
            let users = []
            users.push(result.teacher._id)
            result.students.forEach(item => {
                users.push(item._id)
            })
            await User.update({_id: {$in: users}}, {$pull: {courses: {_id: result._id}}}, {multi: true})
            users[0] = courseInfo.teacher._id
            await User.update({_id: {$in: users}}, {$addToSet: {courses: courseInfo}}, {multi: true})
            ctx.body = setResponse('success', null, '更新成功')
        } else {
            ctx.body = setResponse('failure', null, courseInfo.name + ' 课程信息更新失败')
        }
    } catch (err) {
        ctx.body = setResponse('failure', '系统异常', '更新失败')
    }
}

async function deleteCourse (ctx, next) {
    let id = ctx.params.id
    try {
        let result = await Course.findByIdAndRemove({_id: id}, {select: {teacher: true, students: true}})
        if (result && result.teacher) {
            let users = []
            users.push(result.teacher._id)
            result.students.forEach(item => {
                users.push(item._id)
            })
            await User.update({_id: {$in: users}}, {$pull: {courses: {_id: id}}}, {multi: true})
            ctx.body = setResponse('success', null, '删除成功')
        } else {
            ctx.body = setResponse('failure', null, '删除失败')
        }
    } catch (err) {
        ctx.body = setResponse('failure', err.name, '删除失败')
    }
}

async function deleteCourseList (ctx, next) {
    try {
        let result = await Course.find({_id: {$in: ctx.request.body}}, {teacher: 1, students: 1})
        let len = result.length
        for (let i = 0; i < len; i++) {
            let users = []
            users.push(result[i].teacher._id)
            result[0].students.forEach(s => {
                users.push(s._id)
            })
            let ok = await User.update({_id: {$in: users}}, {$pull: {courses: {_id: result[i]._id}}}, {multi: true})
            if (ok.ok) {
                result[i].remove()
            }
        }
        ctx.body = setResponse('success', null, '删除成功')
    } catch (err) {
        ctx.body = setResponse('failure', null, '删除失败')
    }
}

async function selectCourses (ctx, next) {
    const {student, courses} = ctx.request.body
    try {
        if (Array.isArray(courses)) {
            let selected = []
            courses.forEach(item => {
                selected.push(item._id)
            })
            const result = await User.findByIdAndUpdate({_id: student}, {$addToSet: {courses: {$each: courses}}}, {new: true})
            await Course.update({_id: {$in: selected}}, {$addToSet: {students: result}}, {multi: true})
            ctx.body = setResponse('success', result, '选课成功')
        } else {
            const result = await User.findByIdAndUpdate({_id: student}, {$addToSet: {courses: courses}}, {new: true})
            await Course.findByIdAndUpdate({_id: courses._id}, {$addToSet: {students: result}}, {new: true})
            ctx.body = setResponse('success', result, '选课成功')
        }
    } catch (e) {
        ctx.body = setResponse('failure', '系统错误，选课未成功')
    }
}

async function unselectCourses (ctx, next) {
    const {student, courses} = ctx.request.body
    try {
        if (Array.isArray(courses)) {
            const result = await User.findByIdAndUpdate({_id: student}, {$pull: {courses: {_id: {$in: courses}}}}, {new: true})
            await Course.update({_id: {$in: courses}}, {$pull: {students: {_id: result._id}}}, {multi: true})
            ctx.body = setResponse('success', result, '取消成功')
        } else {
            const result = await User.findByIdAndUpdate({_id: student}, {$pull: {courses: {_id: courses}}}, {new: true})
            await Course.findByIdAndUpdate({_id: courses}, {$pull: {students: {_id: result._id}}})
            ctx.body = setResponse('success', result, '取消成功')
        }
    } catch (e) {
        ctx.body = setResponse('failure', '系统异常，取消课程失败')
    }
}

async function getStudentList (ctx, next) {
    try {
        const course = await Course.findById({_id: ctx.params.id})
        ctx.body = setResponse('success', course.students)
    } catch (err) {
        ctx.body = setResponse('failure', null, '获取该课程学生列表失败')
    }
}

async function setCourseScore (ctx, next) {
    const {courseId, studentId, score} = ctx.request.body
    try {
        const cScore = await Course.update({$and: [{_id: courseId}, {'students._id': studentId}]}, {$set: {'students.$.score': score}})
        const sScore = await User.update({$and: [{_id: studentId}, {'courses._id': courseId}]}, {$set: {'courses.$.score': score}})
        if (cScore.ok === sScore.ok) {
            ctx.body = setResponse('success', null, '录入成绩成功')
        } else {
            ctx.body = setResponse('failure', null, '录入成绩失败')
        }
    } catch (err) {
        ctx.body = setResponse('failure', null, '录入成绩失败')
    }
}

export default {
    route: (router) => {
        router.get('/course/:id', getCourseById)
              .post('/course', createCourse)
              .put('/course', updateCourse)
              .del('/course/:id', deleteCourse)
              .get('/courseList', getCourseList)
              .post('/courseList', deleteCourseList)
              .post('/courseSelect', selectCourses)
              .post('/courseUnselect', unselectCourses)
              .get('/courseStudents/:id', getStudentList)
              .post('/courseScore', setCourseScore)
    }
}