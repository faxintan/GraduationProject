import Router from 'koa-router'
import userCtr from '../controllers/user.js'
import majorCtr from '../controllers/major.js'
import courseCtr from '../controllers/courses.js'
import newsCtr from '../controllers/news.js'

// new Router({prefix: '/user'}) 可以添加路由前缀
const userRouter = new Router()
const majorRouter = new Router()
const courseRouter = new Router()
const newsRouter = new Router()

userCtr.route(userRouter)
majorCtr.route(majorRouter)
courseCtr.route(courseRouter)
newsCtr.route(newsRouter)

// API汇总出口
const router = new Router()
router.use(userRouter.routes())
router.use(majorRouter.routes())
router.use(courseRouter.routes())
router.use(newsRouter.routes())

export default router