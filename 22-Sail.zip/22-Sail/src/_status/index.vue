<template>
<div class="x-status">
    <div class="portrait">
        <div class="logo"></div>
    </div>
    <div class="x-container" style="max-height:none;">
        <div class="row wrap" style="text-align:center;">
            <div class="col1 m_hide"></div>
            <div class="col7 m_expand">
                <x-input v-model="extInfo.school" :placeholder="'请输入'">学校: </x-input>
            </div>
            <div class="col7 m_expand">
                <x-input v-model="extInfo.faculty" :placeholder="'请输入'">院系: </x-input>  
            </div>
            <div class="col1 m_hide"></div>
            <div class="col1 m_hide"></div>
            <div class="col7 m_expand m_first" style="overflow:visible;">
                <x-select style="width:100%;" v-model="extInfo.major"
                        :options="Object.assign({label:'请选择专业'}, majors)"></x-select>
            </div>
            <div class="col7 m_expand">
                <x-input v-model="extInfo.nativePlace" :placeholder="'请输入'">户籍: </x-input>  
            </div>
            <div class="col1 m_hide"></div>
            <div class="col1 m_hide"></div>
            <div class="col7 m_expand">
                <x-input v-model="extInfo.sexual" :placeholder="'请输入'">性别: </x-input>
            </div>
            <div class="col7 m_expand">
                <x-input :type="'number'" v-model="extInfo.age" :placeholder="'请输入'">年龄: </x-input>  
            </div>
            <div class="col1 m_hide"></div>
            <div class="col1 m_hide"></div>
            <div class="col7 m_expand">
                <x-input v-model="extInfo.address" :placeholder="'请输入'">地址: </x-input>
            </div>
            <div class="col7 m_expand">
                <x-input :type="'number'" v-model="extInfo.IdCard" :placeholder="'请输入'">身份证号码: </x-input>  
            </div>
            <div class="col1 m_hide"></div>
            <div class="col1 m_hide"></div>
            <div class="col7 m_expand">
                <input type="date" class="x-date" v-model="extInfo.beginDate" style="width:100%;margin:.4rem 0"
                        :placeholder="extInfo.beginDate?extInfo.beginDate:$user.position==='teacher'?'签约日期':'入学日期'">
            </div>
            <div class="col7 m_expand">
                <input type="date" class="x-date" v-model="extInfo.endDate" style="width:100%;"
                        :placeholder="extInfo.endDate?extInfo.endDate:$user.position==='teacher'?'满约日期':'毕业日期'">
            </div>
            <div class="col1 m_hide"></div>
            <div class="col2 m_hide"></div>
            <div class="col12 m_expand">
                <div class="x-textarea">
                    <div class="e_content" contenteditable="true" @blur="getBriefIntro">{{$user.briefIntro}}</div>
                    <label class="e_title">个人简介</label>
                </div>
            </div>
            <div class="col2 m_hide"></div>
            <div class="col2 m_hide"></div>
            <div class="col12 m_expand">
                <div class="x-textarea">
                    <div class="e_content" contenteditable="true" @blur="getEducation">{{$user.education}}</div>
                    <label class="e_title">教育经历</label>
                </div>
            </div>
            <div class="col2 m_hide"></div>
            <div class="col2 m_hide"></div>
            <div class="col12 m_expand">
                <div class="x-textarea">
                    <div class="e_content" contenteditable="true" @blur="getAward">{{$user.award}}</div>
                    <label class="e_title">获奖情况</label>
                </div>
            </div>
            <div class="col2 m_hide"></div>
        </div>
    </div>
    <div class="x-btn blue" style="width:4.5rem;" @click="submit">保 存</div>
</div>
</template>

<script type="text/javascript">
import {mapGetters, mapActions} from 'vuex'
import {toast} from '../components/Reminder'
import Input from '../components/form/Input2'
import Select from '../components/common/Select'

export default {
    data () {
        return {
            extInfo: Object.assign({beginDate: null, endDate: null}, this.$user)
        }
    },
    computed: {
        ...mapGetters({mList: 'majors'}),
        majors () {
            let temp = {}
            this.mList.forEach(item => {
                temp[item._id] = item.name
            })
            return temp
        }
    },
    methods: {
        ...mapActions(['getMajorList']),
        getBriefIntro (e) {
            this.extInfo.briefIntro = e.target.innerText
        },
        getEducation (e) {
            this.extInfo.education = e.target.innerText
        },
        getAward (e) {
            this.extInfo.award = e.target.innerText
        },
        submit () {
            const ext = this.extInfo
            if (ext.school && ext.faculty && ext.major) {
                this.extInfo.extendInfo = true
            }
            this.$http.put('/user', this.extInfo)
                .then(res => {
                    if (res.data.status === 'success') {
                        window.sessionStorage.setItem('user', JSON.stringify(res.data.result))
                    }
                })
        }
    },
    components: {
        'x-input': Input,
        'x-select': Select
    },
    mounted () {
        if (!this.$user.extendInfo) {
            toast({text: '请完善个人信息'})
        }
        if (!this.majors.length) {
            this.getMajorList()
        }
    }
}
</script>

<style type="text/css">
.x-status{
    display: flex;
    flex-flow: row wrap;
    justify-content: center;
    align-items: flex-start;
    margin-bottom: 3rem;
    padding: .4rem;
    width: 100%;
    min-height: 100%;
    overflow-x: hidden;
}
.x-status .portrait{
    width: 100%;
    text-align: center;
}
.x-status .logo{
    margin: .8rem auto;
    width: 5rem;
    height: 5rem;
    border-radius: 50%;
    background: url('../assets/logo.png') center no-repeat,
                linear-gradient(to bottom, white 45%, #2CB0E6);
    background-size: contain;
}
</style>