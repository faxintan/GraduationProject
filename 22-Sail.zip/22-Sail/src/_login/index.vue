<template>
<div class="x-login"  @keyup.enter="login">
    <div class="container">
        <div class="top">
            <div class="title">登 录</div>
        </div>
        <x-input v-model="config.account" :type="'text'" :placeholder="'请输入账号'"></x-input>
        <x-input v-model="config.password" :type="'password'" :placeholder="'请输入密码'"></x-input>
        <div class="setting">
            <input class="x-checkbox" type="checkbox" v-model="config.keepPsd">
            <label class="e_label">记住密码</label>
            <input class="x-checkbox" type="checkbox" v-model="config.autoLogin">
            <label class="e_label">自动登录</label>
        </div>
        <div class="login">
            <div class="x-btn blue" @click="login">登录</div>
            <div class="x-btn">忘记密码</div>
        </div>
    </div>
    <x-bubble></x-bubble>
</div>
</template>

<script type="text/javascript">
import md5 from 'md5'
import Axios from 'axios'
import jwt from 'jsonwebtoken'
import {toast} from '../components/Reminder'
import Input from '../components/form/Input1'
import Bubble from '../components/canvas/Bubble'

export default {
    data () {
        let init = JSON.parse(window.localStorage.getItem('login')) || {}
        if (!init.keepPsd) {
            init.account = null
            init.password = null
            init.autoLogin = false
        }
        return {
            config: {
                account: init.account,
                password: init.password,
                keepPsd: init.keepPsd,
                autoLogin: init.autoLogin
            }
        }
    },
    components: {
        'x-input': Input,
        'x-bubble': Bubble
    },
    methods: {
        showLogin (show) {
            this.$emit('show', show)
        },
        login () {
            const vm = this
            const config = this.config
            if (config.account && config.password) {
                let user = {
                    account: config.account,
                    password: md5(config.password)
                }
                this.$http.post('/auth/', user)
                    .then((res) => {
                        const data = res.data
                        if (data.status === 'success') {
                            let user = jwt.verify(data.result, 'Louis&Bunny').user
                            window.sessionStorage.setItem('user', JSON.stringify(user))
                            window.sessionStorage.setItem('token', data.result)
                            window.localStorage.setItem('login', JSON.stringify(config))
                            if (user.position !== 'manager' && user.extendInfo === false) {
                                vm.$router.push('/status')
                            } else {
                                vm.$router.push('/home')
                            }
                        } else {
                            toast({text: data.result})
                        }
                    })
            } else {
                if (!config.account) {
                    toast({text: '请输入账号！！！'})
                } else {
                    toast({text: '请输入密码！！！'})
                }
            }
        }
    },
    watch: {
        config: {
            handler: function (val) {
                if (val.autoLogin) {
                    val.keepPsd = true
                }
            },
            deep: true
        }
    },
    beforeRouteEnter (to, from, next) {
        // 自动登录时不进入登录页面
        const config = JSON.parse(window.localStorage.getItem('login')) || {}
        if (to.path !== '/login' && config.autoLogin) {
            let user = {
                account: config.account,
                password: md5(config.password)
            }
            Axios.post('/auth/', user)
                .then((res) => {
                    const data = res.data
                    if (data.status === 'success') {
                        let user = jwt.verify(data.result, 'Louis&Bunny').user
                        window.sessionStorage.setItem('user', JSON.stringify(user))
                        window.sessionStorage.setItem('token', data.result)
                        next()
                    } else {
                        toast({text: data.result})
                        next(false)
                    }
                })
        } else {
            next()
        }
    }
}
</script>

<style type="text/css">
.x-login{
    position: fixed;
    width: 100%;
    height: 100%;
    z-index: 100;
    background: linear-gradient(to top, #FFFFFF, #64DFEE);
}
.x-login .container{
    position: fixed;
    margin: auto;
    height: 13.5rem;
    width: 95%;
    max-width: 16rem;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #FFFFFF;
    box-shadow: 0px 0px 10px #999999;
}
.x-login .top{
    margin-bottom: 1.5rem;
    height: 4rem;
    background: url('../assets/logo.png') 90% no-repeat,
                linear-gradient(to right, #61C0E7 80%, #00FFFF) center no-repeat;
    background-size: contain;
}
.x-login .title{
    position: relative;
    margin: -2px 0 0 -2px;
    width: 4rem;
    height: 1.5rem;
    line-height: 1rem;
    color: #DCF1FA;
    letter-spacing: 2px;
    font-size: .6rem;
    font-weight: bolder;
    text-align: center;
    background: linear-gradient(to top left, #61C0E7, #B8E5F7);
    text-shadow: 2px 3px 5px #61C0E7;
}
.x-login .title:after{
    position: absolute;
    content: '';
    bottom: 0;
    left: 0;
    border-bottom: .4rem solid #61C0E7;
    border-left: 2rem solid transparent;
    border-right: 2rem solid transparent;
}
.x-login .setting{
    margin: auto;
    margin-bottom: .4rem;
    height: 1.5rem;
    line-height: 1.5rem;
    width: 100%;
    max-width: 13rem;
    text-align:right;
}
.x-login .login{
    text-align: center;
    height: 1.2rem;
}
</style>