<template>
    <div class="x-home">
        <div class="row-title">师资生源</div>
        <div class="row m_column">
            <div class="charts teachers">
                <span class="icon-user-tie"></span>
                <div class="detail">
                    <div class="ratio">800/1500</div>
                    <div class="topic">高级教师/教师总人数</div>
                </div>
            </div>
            <div class="charts students">
                <span class="icon-user-tie"></span>
                <div class="detail">
                    <div class="ratio">5200/8000</div>
                    <div class="topic">优秀学生/学生总人数</div>
                </div>
            </div>
            <div class="charts worker">
                <span class="icon-user-tie"></span>
                <div class="detail">
                    <div class="ratio">1000/1500</div>
                    <div class="topic">优秀外勤/外勤总人数</div>
                </div>
            </div>
        </div>
        <div class="row-title">消息面板</div>
        <div class="row" :style="{'display':$isMobile?'block':'flex'}">
            <x-carousel :length="$isMobile?3:0">
                <div class="msg-box" :class="{'mobile_box':$isMobile}">
                    <x-panel :title="'学校公告'">
                        <span slot="icon" class="icon-cog"></span>
                        <li class="information" v-for="s in school" @click="lookin(s)">
                            {{s.title}}<span>{{s.date?s.date.substr(5,5):''}}</span>
                        </li>
                        <div class="more">查看更多 &gt;&gt;</div>
                    </x-panel>
                </div>
                <div class="msg-box" :class="{'mobile_box':$isMobile}">
                    <x-panel :title="'奖励通告'">
                        <span slot="icon" class="icon-cog"></span>
                        <li class="information" v-for="a in award" @click="lookin(a)">
                            {{a.title}}<span>{{a.date?a.date.substr(5,5):''}}</span>
                        </li>
                        <div class="more">查看更多 &gt;&gt;</div>
                    </x-panel>
                </div>
                <div class="msg-box" :class="{'mobile_box':$isMobile}">
                    <x-panel :title="'用户消息'">
                        <span slot="icon" class="icon-cog"></span>
                        <li class="information" v-for="u in user" @click="lookin(u)">
                            {{u.title}}<span>{{u.date?u.date.substr(5,5):''}}</span>
                        </li>
                        <div class="more">查看更多 &gt;&gt;</div>
                    </x-panel>
                </div>
            </x-carousel>
        </div>
        <div class="row-title">互动环节</div>
        <div class="row" style="flex-flow:row nowrap;">
            <x-carousel :length="$isMobile?3:0">
                <div class="msg-box" :class="{'mobile_box':$isMobile}">
                    <x-panel :title="'完成项目后...'">
                        <span slot="icon" class="icon-cog"></span>
                        <div class="funny"></div>
                    </x-panel>
                </div>
                <div class="msg-box" :class="{'mobile_box':$isMobile}">
                    <x-panel :title="'获奖教师比例'">
                        <span slot="icon" class="icon-cog"></span>
                        <pie-chart :percent="90" :config="{
                                        round: '.6rem',
                                        inner: '#B486F8',
                                        outterA: '#FBC262',
                                        outterB: '#EEEEEE',
                                        label1: '优秀教师',
                                        label2: '普通教师'
                                    }"></pie-chart>
                    </x-panel>
                </div>
                <div class="msg-box" :class="{'mobile_box':$isMobile}">
                    <x-panel :title="'获奖学生比例'">
                        <span slot="icon" class="icon-cog"></span>
                        <pie-chart :percent="40" :config="{
                                        round: '.6rem',
                                        inner: '#72B8FB',
                                        outterA: '#89EB78',
                                        outterB: '#EEEEEE',
                                        label1: '优秀学生',
                                        label2: '普通学生'
                                    }"></pie-chart>
                    </x-panel>
                </div>
            </x-carousel>
        </div>
    </div>
</template>

<script type="text/javascript">
import {mapGetters, mapActions} from 'vuex'
import {showArticle} from '../components/Reminder'
import Panel from '../components/common/Panel'
import PieChart from '../components/common/PieChart'
import Carousel from '../components/common/Carousel'

export default {
    computed: {
        ...mapGetters({
            news: 'news'
        }),
        school () {
            var arr = this.news.filter(item => {
                return item.type === 'school'
            })
            arr.splice(6)
            return arr
        },
        award () {
            var arr = this.news.filter(item => {
                return item.type === 'award'
            })
            arr.splice(6)
            return arr
        },
        user () {
            var arr = this.news.filter(item => {
                return item.type === 'user'
            })
            arr.splice(6)
            return arr
        }
    },
    components: {
        'x-panel': Panel,
        'pie-chart': PieChart,
        'x-carousel': Carousel
    },
    methods: {
        ...mapActions(['getNewsList']),
        lookin (article) {
            showArticle(article)
        }
    },
    mounted () {
        if (!this.news.length) {
            this.getNewsList()
        }
    }
}
</script>

<style type="text/css">
.x-home{
    margin-bottom: 3rem;
    width: 100%;
    min-height: 100%;
}
.x-home .row{
    display: flex;
    justify-content: space-around;
    align-items: stretch;
    padding: 0 .4rem;
}
.x-home .row-title{
    padding-left: .4rem;
    margin: .8rem .4rem .4rem;
    margin-left: .4rem;
    height: .56rem;
    line-height: .6rem;
    font-size: .64rem;
    border-left: .2rem solid #fc923f;
}
.x-home .charts{
    margin: .4rem .2rem;
    height: 3.2rem;
    line-height: 3.5rem;
    width: 30%;
    min-width: 8rem;
    max-width: 14rem;    
    text-align: center;
    color: white;
    border-radius: 5px;
    box-shadow: 2px 3px 10px #999999;
    overflow: hidden;
}
.x-home .charts span{
    font-size: .88rem;
}
.x-home .detail{
    display: inline-block;
    margin-left: .2rem;
    height: 3.2rem;
    text-align: center;
    vertical-align: top;
}
.x-home .ratio{
    height: 2rem;
    line-height: 2.5rem;
    font-size: 1rem;
}
.x-home .topic{
    height: 1.2rem;
    line-height: .5rem;
    font-size: .48rem;
}
.x-home .teachers{
    background-image:linear-gradient(-90deg, #b59def 0%, #a991e2 100%);
}
.x-home .students{
    align-self: flex-end;
    background-image:linear-gradient(90deg, #66c5e9 0%, #7fd2f1 100%);
}
.x-home .worker{
    background-image:linear-gradient(90deg, #f6c660 0%, #f6c660 100%);
}
.x-home .msg-box{
    margin: .4rem 0;
    width: calc(30% + .4rem);
    min-width: 8.4rem;
    max-width: 14.4rem;
    overflow: hidden;
}
.x-home .mobile_box{
    width: 100%;
    max-width: 100%;
}
.x-home .information{
    position: relative;
    padding-right: 1.9rem;
    height: 1.2rem;
    line-height: 1.2rem;
    color: #666666;
    cursor: pointer;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.x-home .information:hover{
    color: #1BA1D6;
}
.x-home .information:active{
    color: #0582B4;
}
.x-home .information span{
    position: absolute;
    right: 0;
    color: #FC923F;
    font-size: .48rem;
    text-shadow: 1px 1px 5px #DDDDDD;
}
.x-home .more{
    margin-top: .8rem;
    font-size: .48rem;
    text-align: right;
    color: #72CBED;
    text-shadow: 1px 1px 5px #DDDDDD;
}
.x-home .funny{
    height: 6rem;
    width: 100%;
    background: url('../assets/lovely.jpg') center no-repeat;
    background-size: contain;
}
</style>