<template>
    <div class="x-course">
        <div class="wrapper">
            <div class="top">
                <x-search :style="{'margin-right':'1.2rem'}" v-model="search.text"></x-search>
                <x-select v-model="search.type"
                    :options="Object.assign({all:'全部',selected:'已选',unselect:'未选'}, fields)"></x-select>
                <div class="manage" v-if="$user&&$user.position==='manager'">
                    <div class="x-btn blue" @click="showDataCard(false)">添加课程</div>
                    <div class="x-btn m_hide" @click="delCourse(true)">删除课程</div>
                </div>
                <div class="manage" v-if="$user&&$user.position==='student'">
                    <div class="x-btn blue" @click="addOrUpdateCourse(true)">确认选课</div>
                    <div class="x-btn m_hide" @click="delCourse(true)">取消选课</div>
                </div>
            </div>
            <div class="x-container">
                <div class="row title">
                    <div class="col1 m_hide" v-if="$user.position!=='teacher'"></div>
                    <div class="col5">课程信息</div>
                    <div class="col2 m_hide center">类别</div>
                    <div class="col2 m_hide center">授课老师</div>
                    <div class="col2 m_hide center">推荐指数</div>
                    <div class="col1 center">学分</div>
                    <div class="col3 center">课程时长</div>
                </div>
            </div>
            <div class="x-container m_small" style="min-height:9rem;">
                <div class="row content" v-for="c in courses" @click="showDataCard(c)">
                    <div class="col1 m_hide" @click.stop  v-if="$user.position!=='teacher'">
                        <input class="x-checkbox" style="margin-left:.3rem;"
                               type="checkbox"
                               :value="c._id"
                               v-model="selected">
                    </div>
                    <div class="col5">
                        <div class="photo"></div>
                        <div class="detail">
                            <div class="name">{{c.name}}</div>
                            <div class="description">{{c.intro}}</div>
                        </div>
                    </div>
                    <div class="col2 m_hide center">{{fields[c.field]}}</div>
                    <div class="col2 m_hide center">{{c.teacher.name}}</div>
                    <div class="col2 m_hide center">★★★☆☆</div>
                    <div class="col1 center">{{c.credit}}</div>
                    <div class="col3 center" style="overflow:visible;">
                        <div class="time"><span class="icon-calendar"></span>{{c.beginDate}}</div>
                        <div class="time"><span class="icon-calendar"></span>{{c.endDate}}</div>
                    </div>
                </div>
            </div>
        </div>
        <x-datacard v-model="showCard" :title="'课程信息'" :yes="yes" :no="no"
                @confirm="addOrUpdateCourse"
                @cancel="delCourse(false)">
            <div class="x-container">
                <div class="row wrap" v-if="$user.position !== 'manager'">
                    <div class="col1"></div>
                    <div class="col6 item m_small"><span>课程: </span>{{course.name}}</div>
                    <div class="col2"></div>
                    <div class="col6 item m_small"><span>类别: </span>{{fields[course.field]}}</div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                    <div class="col6 item m_small"><span>老师: </span>{{course.teacher.name}}</div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                    <div class="col6 item m_small"><span>学分: </span>{{course.credit}}</div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                    <div class="col6 item m_small">
                        <span>开课: </span>{{course.beginDate?course.beginDate:''}}</div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                    <div class="col6 item m_small">
                        <span>结束: </span>{{course.endDate?course.endDate:''}}
                    </div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                    <div class="col14 item m_small" style="margin-bottom:-1.5rem;height:auto;border:none;color:#666666;white-space:pre-wrap;">
                        <span>课程简介：</span>{{course.intro}}
                    </div>
                    <div class="col1"></div>
                </div>
                <div class="row wrap" v-else>
                    <div class="col1"></div>
                    <div class="col6 m_expand"><x-input v-model="course.name">课程</x-input></div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                    <div class="col6 m_expand">
                        <x-input :type="'number'" v-model="course.credit">学分</x-input>
                    </div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                    <div class="col6 m_expand visible">
                        <x-select class="select" v-model="course.teacher._id"
                            :options="Object.assign({label:'选择任课老师'}, teachers)">
                        </x-select>
                    </div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                    <div class="col6 m_expand visible">
                        <x-select class="select" :options="Object.assign({label:'选择课程类别'}, fields)" v-model="course.field"></x-select>
                    </div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                    <div class="col6 m_expand">
                        <input type="date" class="x-date select" v-model="course.beginDate"
                               :placeholder="course.beginDate?course.beginDate:'选择开课时间'">
                    </div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                    <div class="col6 m_expand">
                        <input type="date" class="x-date select" v-model="course.endDate"
                               :placeholder="course.endDate?course.endDate:'选择结束时间'">
                    </div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                    <div class="col14 m_expand">
                        <div class="x-textarea">
                            <div class="e_content" contenteditable="true" @blur="getIntroduction">{{course.intro}}</div>
                            <label class="e_title">课程介绍</label>
                        </div>
                    </div>
                    <div class="col1"></div>
                </div>
            </div>
        </x-datacard>
    </div>
</template>

<script type="text/javascript">
import {mapGetters, mapActions} from 'vuex'
import {toast} from '../components/Reminder'
import Input from '../components/form/Input2'
import Select from '../components/common/Select'
import Search from '../components/common/Search'
import DataCard from '../components/common/DataCard'

export default {
    data () {
        return {
            add: false,
            showCard: false,
            selected: [],
            search: {text: '', type: 'all'},
            course: {beginDate: '', endDate: '', teacher: {}}
        }
    },
    computed: {
        ...mapGetters({
            cList: 'courses',
            tList: 'teachers'
        }),
        yes () {
            switch (this.$user.position) {
            case 'student': return '选择课程'
            case 'teacher': return null
            case 'manager': return this.add ? '添加课程' : '保存更改'
            }
        },
        no () {
            switch (this.$user.position) {
            case 'student': return '取消课程'
            case 'teacher': return null
            case 'manager': return this.add ? '取消' : '删除'
            }
        },
        teachers () {
            let teacher = {}
            this.tList.forEach(item => {
                teacher[item._id] = item.name
            })
            return teacher
        },
        fields () {
            return {basic: '公共基础', techno: '科学技术', math: '数学算法', article: '文学散文', foreign: '外语精通', music: '古典音乐', movie: '影视技术'}
        },
        courses () {
            const search = this.search
            if (search.type === 'selected' || search.type === 'unselect') {
                let selected = this.$user.courses
                let contain = function (arr, item) {
                    let len = arr.length
                    for (let i = 0; i < len; i++) {
                        if (arr[i]._id === item._id) {
                            return true
                        }
                    }
                }
                if (search.type === 'selected') {
                    return this.cList.filter(item => {
                        return contain(selected, item)
                    })
                } else {
                    return this.cList.filter(item => {
                        return !contain(selected, item)
                    })
                }
            } else {
                return this.cList.filter(item => {
                    return (item.field === search.type || search.type === 'all') &&
                            (item.name.match(search.text) || search.text === '')
                })
            }
        }
    },
    methods: {
        ...mapActions([
            'getTeacherList',
            'getCourseList',
            'addCourse',
            'updateCourse',
            'deleteCourse',
            'selectCourses',
            'unselectCourses']),
        getIntroduction (e) {
            this.course.intro = e.target.innerText
        },
        showDataCard (course) {
            if (course) {
                this.add = false
                this.course = Object.assign({}, course)
                this.course.teacher = Object.assign({}, course.teacher)
            } else {
                this.add = true
                this.course = {beginDate: '', endDate: '', teacher: {}}
            }
            this.showCard = true
        },
        addOrUpdateCourse (multi) {
            if (this.$user && this.$user.position === 'manager') {
                // 管理员管理课程信息
                let course = this.course
                if (!course.name) {
                    toast({text: '请输入 课程名称'})
                    return
                }
                if (!course.credit) {
                    toast({text: '请输入 课程学分'})
                    return
                }
                if (!course.teacher) {
                    toast({text: '请选择 任课老师'})
                    return
                }
                if (!course.field) {
                    toast({text: '请选择 课程类别'})
                    return
                }
                if (!course.beginDate) {
                    toast({text: '请选择 开课时间'})
                    return
                }
                if (!course.endDate) {
                    toast({text: '请选择 课程结束时间'})
                    return
                }
                if (!course.intro) {
                    toast({text: '请输入 课程介绍'})
                    return
                }
                course.teacher.name = this.teachers[course.teacher._id]
                if (this.add) {
                    this.addCourse(course)
                } else {
                    this.updateCourse(course)
                }
                this.showCard = false
            } else {
                // 学生选择课程
                if (multi) {
                    if (this.selected.length) {
                        this.selectCourses({student: this.$user._id, courses: this.selected})
                        this.selected = []
                    } else {
                        toast({text: '请选择课程'})
                    }
                } else {
                    this.selectCourses({student: this.$user._id, courses: this.course})
                    this.course = {beginDate: '', endDate: '', teacher: {}}
                    this.showCard = false
                }
            }
        },
        delCourse (multi) {
            if (this.$user && this.$user.position === 'manager') {
                if (multi) {
                    if (this.selected.length) {
                        this.deleteCourse(this.selected)
                        this.selected = []
                    } else {
                        toast({text: '请先选择需要删除的课程'})
                    }
                } else {
                    this.deleteCourse(this.course)
                    this.course = {beginDate: '', endDate: '', teacher: {}}
                    this.showCard = false
                }
            } else {
                let data = {student: this.$user._id}
                if (multi) {
                    if (this.selected.length) {
                        data.courses = this.selected
                        this.unselectCourses(data)
                        this.selected = []
                    } else {
                        toast({text: '请先选择需要取消的课程'})
                    }
                } else {
                    data.courses = this.course._id
                    this.unselectCourses(data)
                    this.course = {beginDate: '', endDate: '', teacher: {}}
                    this.showCard = false
                }
            }
        }
    },
    mounted () {
        if (!this.cList.length) {
            this.getCourseList()
        }
        if (!this.tList.length) {
            this.getTeacherList()
        }
    },
    components: {
        'x-input': Input,
        'x-select': Select,
        'x-search': Search,
        'x-datacard': DataCard
    }
}
</script>

<style type="text/css">
.x-course{
    width: 100%;
    height: 100%;
}
.x-course .wrapper{
    padding: .5rem;
}
.x-course .top{
    margin-bottom: .4rem;
    /*height: 1.5rem;*/
    min-height: 1.5rem;
    line-height: 1.5rem;

}
.x-course .manage{
    display: inline-block;
    float: right;
}
.x-course .title{
    font-weight: bold;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    background-color: #CCCCCC;
}
.x-course .content{
    margin-top: .4rem;
    border-radius: .2rem;
    background-color: #FFFFFF;
}
.x-course .content:hover{
    border: 1px solid #00FFFF;
    box-shadow: inset 0 0 10px rgba(0, 255, 255, .7);
}
.x-course .photo{
    float: left;
    width: 2rem;
    height: 2rem;
    border-radius: 50%;
    background: url('../assets/logo.png') center no-repeat;
    background-color: #EAEAEA;
    background-size: contain;
}
.x-course .detail{
    margin-left: 2.3rem;
    height: 2rem;
}
.x-course .name{
    padding: .2rem 0;
}
.x-course .description{
    font-size: .48rem;
    color: #999999;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.x-course .center{
    text-align: center;
}
.x-course .item{
    height: 1.5rem;
    line-height: 1rem;
    font-size: .56rem;
    text-align: left;
    border-bottom: 1px solid #EAEAEA;
}
.x-course .item span{
    color: #333333;
    font-weight: bold;
    letter-spacing: 1px;
}
.x-course .time{
    height: 1rem;
    line-height: 1rem;
    color: #00FFFF;
}
.x-course .time span{
    margin-top: .2rem;
    margin-right: .2rem;
}
.x-course .visible{
    overflow: visible;
}
.x-course .select{
    width: 100%;
    border-radius: 5px;
}
</style>