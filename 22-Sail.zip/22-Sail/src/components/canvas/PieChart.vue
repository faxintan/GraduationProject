<template>
<div class="x-pie_chart" ref="pieChartWrapper">
    <canvas ref="pieChart"></canvas>
</div>
</template>

<script type="text/javascript">
// config = {outter, type='circle,round'}
// data = [{label, value, color}]
export default {
    props: {
        config: {
            type: Object,
            default: function () {
                return {
                    outter: 10,
                    type: 'round'
                }
            }
        },
        data: {
            type: Array,
            default: function () {
                return [{label: '百分比', value: 100, color: 'blue'}]
            }
        }
    },
    data () {
        return {
            width: 0,
            height: 0,
            context: null,
            turn: 0,
            index: 0,
            radius: 0,
            animation: null,
            deg: Math.PI / 50,
            pos: [0]
        }
    },
    methods: {
        init () {
            const vm = this
            vm.turn = 0
            vm.index = 0
            vm.pos = [0]
            var sum = 0
            vm.data.forEach((item, index) => {
                sum += item.value
                if (sum <= 100) {
                    vm.pos.push(sum)
                } else {
                    vm.pos.push(100)
                }
            })
            vm.radius = (Math.min(vm.width, vm.height) - vm.config.outter) / 2
            this.drawPieChart()
        },
        drawLabel () {
            const ctx = this.context
            var x = 0
            var y = 0
            ctx.font = '13px Calibri'
            ctx.textBaseline = 'top'
            if (this.height < this.width) {
                x = (this.width + this.config.outter) / 2 + 10
                y = this.config.outter + 10
                this.data.forEach((item, index) => {
                    ctx.fillStyle = item.color
                    ctx.fillRect(x, y + index * 20, 13, 13)
                    ctx.fillStyle = '#333333'
                    ctx.fillText(item.label + ' ' + item.value + '%', x + 18, y + index * 20 - 1)
                })
            } else {
                x = this.config.outter + 10
                y = this.height / 2 + this.radius + 10
                this.data.forEach((item, index) => {
                    ctx.fillStyle = item.color
                    ctx.fillRect(x + index * 100, y, 13, 13)
                    ctx.fillStyle = '#333333'
                    ctx.fillText(item.label + ' ' + item.value + '%', x + index * 100 + 15, y)
                })
            }
        },
        drawPieChart () {
            const vm = this
            const ctx = this.context
            const pos = this.pos
            const deg = this.deg
            const data = this.data
            const radius = this.radius
            const config = this.config
            const centerX = this.width / 2 - radius
            const centerY = this.height / 2
            vm.animation = window.requestAnimationFrame(this.drawPieChart)
            ctx.lineWidth = config.outter
            if (vm.turn >= 100) {
                window.cancelAnimationFrame(vm.animation)
                this.drawLabel()
                return
            }
            if (vm.index < data.length) {
                ctx.clearRect(0, 0, this.width, this.height)
                for (let i = 0; i < vm.index; i++) {
                    ctx.beginPath()
                    ctx.arc(centerX, centerY, radius, pos[i] * deg, pos[i + 1] * deg, false)
                    if (config.type === 'circle') {
                        ctx.lineTo(centerX, centerY)
                        ctx.fillStyle = data[i].color
                        ctx.fill()
                    } else {
                        ctx.strokeStyle = data[i].color
                        ctx.stroke()
                    }
                }
                ctx.beginPath()
                ctx.arc(centerX, centerY, vm.radius, pos[vm.index] * deg, ++vm.turn * deg, false)
                if (config.type === 'circle') {
                    ctx.lineTo(centerX, centerY)
                    ctx.fillStyle = data[vm.index].color
                    ctx.fill()
                } else {
                    ctx.strokeStyle = data[vm.index].color
                    ctx.stroke()
                }
                if (vm.turn === pos[vm.index + 1]) {
                    vm.index++
                }
            }
        },
        resize () {
            this.width = this.$refs.pieChartWrapper.clientWidth
            this.height = this.$refs.pieChartWrapper.clientHeight
            this.$refs.pieChart.width = this.width
            this.$refs.pieChart.height = this.height
            window.cancelAnimationFrame(this.animation)
            this.init()
        }
    },
    mounted () {
        this.width = this.$refs.pieChartWrapper.clientWidth
        this.height = this.$refs.pieChartWrapper.clientHeight
        this.$refs.pieChart.width = this.width
        this.$refs.pieChart.height = this.height
        this.context = this.$refs.pieChart.getContext('2d')
        this.init()
    },
    created () {
        window.addEventListener('resize', this.resize)
    },
    destroyed () {
        window.removeEventListener('resize', this.resize)
    }
}
</script>

<style type="text/css">
.x-pie_chart{
    width: 100%;
    height: 100%;
}
</style>