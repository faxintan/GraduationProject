<template>
    <div class="x-bubble" ref="bubbleWrapper">
        <canvas class="e_canvas" ref="bubble">
            <div style="background:grey">不支持Canvas</div>
        </canvas>
    </div>
</template>

<script type="text/javascript">
export default {
    data () {
        return {
            width: 0,
            height: 0,
            context: null,
            animation: null,
            circles: []
        }
    },
    methods: {
        init (num) {
            for (let i = 0; i < num; i++) {
                let props = {}
                props.x = Math.random() * this.width
                props.y = Math.random() * 20 + this.height
                props.alpha = 0.1 + Math.random() * 0.4
                props.scale = 0.1 + Math.random() * 0.3
                props.velocity = Math.random()
                this.circles.push(props)
            }
            this.drawPop()
        },
        resetCircle (index) {
            if (index < this.circles.length) {
                let props = {}
                props.x = Math.random() * this.width
                props.y = Math.random() * 10 + this.height
                props.alpha = 0.1 + Math.random() * 0.4
                props.scale = 0.1 + Math.random() * 0.3
                // props.color = 'rgba(' + parseInt(Math.random() * 255) + ',' +
                //               parseInt(Math.random() * 255) + ',' +
                //               parseInt(Math.random() * 255) + ',' +
                //               props.alpha + ')'
                props.velocity = Math.random()
                this.circles[index] = props
            }
        },
        drawPop () {
            const ctx = this.context
            ctx.clearRect(0, 0, this.width, this.height)
            for (let i = 0; i < this.circles.length; i++) {
                let c = this.circles[i]
                if (c.alpha <= 0) {
                    this.resetCircle(i)
                }
                c.y -= c.velocity
                c.alpha -= 0.001
                ctx.beginPath()
                ctx.arc(c.x, c.y, c.scale * 20, 0, 2 * Math.PI, false)
                ctx.fillStyle = 'rgba(0,255,255,' + c.alpha + ')'
                ctx.fill()
            }
            this.animation = window.requestAnimationFrame(this.drawPop)
        },
        resize () {
            this.width = this.$refs.bubbleWrapper.clientWidth
            this.height = this.$refs.bubbleWrapper.clientHeight
            this.$refs.bubble.width = this.width
            this.$refs.bubble.height = this.height
        }
    },
    mounted () {
        this.width = this.$refs.bubbleWrapper.clientWidth
        this.height = this.$refs.bubbleWrapper.clientHeight
        this.$refs.bubble.width = this.width
        this.$refs.bubble.height = this.height
        this.context = this.$refs.bubble.getContext('2d')
        this.init(this.width * 0.1)
    },
    created () {
        window.addEventListener('resize', this.resize)
    },
    destroyed () {
        window.removeEventListener('resize', this.resize)
        window.cancelAnimationFrame(this.animation)
    }
}
</script>

<style type="text/css">
.x-bubble{
    display: flex;
    justify-content: center;
    width: 100%;
    height: 100%;
}
</style>