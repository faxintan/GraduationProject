<template>
    <div class="x-line_chart" ref="lineChartWrapper">
        <canvas ref="lineChart">
            <div style="background:grey">不支持Canvas</div>
        </canvas>
        <canvas ref="line" style="position:absolute;"></canvas>
    </div>
</template>

<script type="text/javascript">
// config: {rows: 5, incre: 20, init: 20, color: 'blue'}
// data: [{x: 'Jan', y: 5}]
export default {
    props: {
        config: {
            type: Object,
            default: function () { return {} }
        },
        data: {
            type: Array,
            required: true
        }
    },
    data () {
        return {
            width: 0,
            height: 0,
            context1: null,
            context2: null
        }
    },
    methods: {
        drawlineChart () {
            const ctx = this.context1
            const data = this.data
            const config = this.config
            const gapX = (this.width - 70) / (data.length)
            const gapY = (this.height - 50) / (config.rows + 1)
            const beginY = this.height - 30
            const inchY = gapY / config.incre
            ctx.clearRect(0, 0, this.width, this.height)
            // XY 边框
            ctx.beginPath()
            ctx.moveTo(40, 20)
            ctx.lineTo(40, this.height - 30)
            ctx.lineTo(this.width - 40, this.height - 30)
            ctx.strokeStyle = '#CCCCCC'
            ctx.stroke()
            // X 坐标轴
            ctx.textBaseline = 'middle'
            ctx.strokeStyle = '#EEEEEE'
            ctx.fillStyle = '#999999'
            ctx.textAlign = 'center'
            for (let i = 0; i < data.length; i++) {
                ctx.fillText(data[i].x, (i + 0.5) * gapX + 40, this.height - 15)
            }
            // Y 坐标轴
            ctx.textAlign = 'right'
            for (let i = 0; i < config.rows; i++) {
                let y = (config.rows - i) * gapY + 20
                ctx.beginPath()
                ctx.moveTo(40, y)
                ctx.lineTo(this.width - 30, y)
                ctx.stroke()
                ctx.fillText(config.init + config.incre * (i + 1), 30, y)
            }
            // 只有一个canvas情况
            // ctx.clearRect(0, 0, this.width, this.height)
            ctx.beginPath()
            ctx.moveTo(40 + gapX * 0.5, beginY)
            for (let i = 0; i < data.length; i++) {
                ctx.lineTo(40 + gapX * (i + 0.5), beginY - (data[i].y - config.init) * inchY)
            }
            ctx.lineTo(40 + gapX * (data.length - 0.5), beginY)
            ctx.fillStyle = config.color
            ctx.fill()
            ctx.strokeStyle = 'white'
            ctx.fillStyle = config.color
            ctx.lineWidth = 3
            for (let i = 0; i < data.length; i++) {
                ctx.beginPath()
                ctx.arc(40 + gapX * (i + 0.5), beginY - (data[i].y - config.init) * inchY, 3, 0, Math.PI * 2, true)
                ctx.closePath()
                ctx.stroke()
                ctx.fill()
            }
        },
        // drawLine () {
        //     const ctx = this.context2
        //     const data = this.data
        //     const config = this.config
        //     const gapX = (this.width - 70) / (data.length)
        //     const gapY = (this.height - 50) / (config.rows + 1)
        //     const beginY = this.height - 30
        //     const inchY = gapY / config.incre
        //     ctx.clearRect(0, 0, this.width, this.height)
        //     ctx.beginPath()
        //     ctx.moveTo(40 + gapX * 0.5, beginY)
        //     for (let i = 0; i < data.length; i++) {
        //         ctx.lineTo(40 + gapX * (i + 0.5), beginY - (data[i].y - config.init) * inchY)
        //     }
        //     ctx.lineTo(40 + gapX * (data.length - 0.5), beginY)
        //     ctx.fillStyle = config.color
        //     ctx.fill()
        //     ctx.strokeStyle = 'white'
        //     ctx.fillStyle = config.color
        //     ctx.lineWidth = 3
        //     for (let i = 0; i < data.length; i++) {
        //         ctx.beginPath()
        //         ctx.arc(40 + gapX * (i + 0.5), beginY - (data[i].y - config.init) * inchY, 3, 0, Math.PI * 2, true)
        //         ctx.closePath()
        //         ctx.stroke()
        //         ctx.fill()
        //     }
        // },
        resize () {
            this.width = this.$refs.lineChartWrapper.clientWidth
            this.height = this.$refs.lineChartWrapper.clientHeight
            this.$refs.lineChart.width = this.$refs.line.width = this.width
            this.$refs.lineChart.height = this.$refs.line.height = this.height
            this.drawlineChart()
            // this.drawLine()
        }
    },
    mounted () {
        this.width = this.$refs.lineChartWrapper.clientWidth
        this.height = this.$refs.lineChartWrapper.clientHeight
        this.$refs.lineChart.width = this.$refs.line.width = this.width
        this.$refs.lineChart.height = this.$refs.line.height = this.height
        this.context1 = this.$refs.lineChart.getContext('2d')
        this.context2 = this.$refs.line.getContext('2d')
        this.drawlineChart()
        // this.drawLine()
    },
    created () {
        window.addEventListener('resize', this.resize)
    },
    destroyed () {
        window.removeEventListener('resize', this.resize)
    }
}
</script>

<style type="text/css">
.x-line_chart{
    position: relative;
    display: flex;
    justify-content: center;
    width: 100%;
    height: 100%;
}
</style>