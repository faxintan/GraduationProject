<template>
    <div class="monkey">
        <div class="body">
            <div class="face"></div>
            <div class="face right"></div>
            <div class="ear"><span></span></div>
            <div class="ear right"><span></span></div>
            <div class="eye"></div>
            <div class="eye right"></div>
            <div class="flush"><span></span></div>
            <div class="mouth"><span></span></div>
            <div class="hand"></div>
            <div class="hand right"></div>
        </div>
        <div class="shadow"></div>
    </div>
</template>

<style type="text/css">
.monkey{
    position: relative;
    height: 130px;
    width: 110px;
    /*background: rgba(0, 100, 100, .3);*/
}
.monkey div, .monkey span{
    position: absolute;
}
/* 小猴子主体， 定位原点 */
.monkey .body{
    width: 90px;
    height: 100px;
    top: 10px;
    left: 10px;
    background: #D8B262;
    border-radius: 50% 50% 50% 50%/40% 40% 60% 60%;
    box-shadow: inset 10px -6px 10px rgba(0, 0, 0, 0.1);
    animation: upsideDown-monkey 1.5s infinite;
}
.monkey .face{
    width: 50px;
    height: 70px;
    border-radius: 50%;
    background: radial-gradient(at 50% 50%, #FF9292, #F7AA95);
    transform: translate(15px, 30px) rotate(-45deg);
}
.monkey .face.right{
    transform: translate(25px, 30px) rotate(45deg);
}
/* 小猴子耳朵 */
.monkey .ear{
    width: 15px;
    height: 20px;
    top: 45px;
    left: -7px;
    background: #D8B262;
    border-radius: 60% 50% 20% 80%;
}
.monkey .ear.right{
    left: 80px;
    border-radius: 40% 60% 80% 50%;
}
.monkey .ear span{
    width: 8px;
    height: 13px;
    top: 4px;
    left: 4px;
    border-radius: 60% 50% 20% 80%;
    background: #FED7E4;
}
.monkey .ear.right span{
    left: 4px;
    border-radius: 40% 60% 80% 50%;
}
/* 小猴子眼睛 */
.monkey .eye{
    width: 20px;
    height: 20px;
    top: 50px;
    left: 20px;
    border-radius: 50%;
    background: radial-gradient(at 50% 50%, #FFFFFF 25%, #333333 30%, #666666);
    animation: eyes-monkey 1.5s infinite;
}
.monkey .eye.right{
    left: 52px;
}
/* 小猴子小红晕 */
.monkey .flush{
    width: 20px;
    height: 10px;
    top: 75px;
    left: 15px;
    border-radius: 70%;
    background: radial-gradient(at 50% 50%, #F64129, #F3B8AF);
}
.monkey .flush span{
    width: 20px;
    height: 10px;
    right: -40px;
    border-radius: 70%;
    background: radial-gradient(at 50% 50%, #F64129, #F3B8AF);
}
/* 小猴子小嘴 */
.monkey .mouth{
    width: 10px;
    height: 10px;
    left: 35px;
    bottom: 10px;
    border-bottom: 1px solid black;
    border-radius: 50%;
    animation: mouth-monkey 1.5s infinite;
}
.monkey .mouth span{
    display: inline-block;
    width: 10px;
    height: 10px;
    left: 9px;
    border-bottom: 1px solid black;
    border-radius: 50%;
}
/* 小猴子小手 */
.monkey .hand{
    width: 20px;
    height: 20px;
    bottom: -5px;
    left: 10px;
    border-radius: 50%;
    border: 1px solid #D8B262;
    box-shadow: inset 0 0 5px #D8B262;
    background: radial-gradient(at 50% 50%, #FF9292 20%, #E6CE99 70%, #D8B262);
    animation: arm-monkey .5s infinite;
}
.monkey .hand.right{
    left: 60px;
    animation: arm-monkey .5s infinite .25s;
}
.monkey .shadow{
    width: 50px;
    height: 10px;
    bottom: 3px;
    left: 30px;
    border-radius: 50%;
    background: radial-gradient(at center center, #666666, #AAAAAA);
    animation: shadow-monkey 1.5s infinite;
}
/* 动画 */
@keyframes upsideDown-monkey{
    50% {
        transform: translateY(-5px);
        border-radius: 50% 50% 50% 50%/40% 40% 50% 50%;
    }
}
@keyframes eyes-monkey{
    50% {
        transform: scaleY(1.05);
    }
}
@keyframes mouth-monkey{
    50% {
        transform: scale(.9);
    }
}
@keyframes arm-monkey{
    33% {
        /*transform: scale(1.1);*/
        transform: translate(5px);
    }
    66% {
        /*transform: scale(.9);*/
        transform: translate(-5px);
    }
}
@keyframes shadow-monkey{
    50% {
        transform: scale(.7);
    }
}
</style>
