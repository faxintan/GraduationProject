<template>
    <div class="bunny">
        <div class="body">
            <div class="ear"><span></span></div>
            <div class="ear right"><span></span></div>
            <div class="eye"><span></span></div>
            <div class="eye right"><span></span></div>
            <div class="flush"><span></span></div>
            <div class="mouth"></div>
            <div class="hand"></div>
            <div class="hand right"></div>
        </div>
        <div class="shadow"></div>
    </div>
</template>

<style type="text/css">
.bunny{
    position: relative;
    height: 180px;
    width: 120px;
    /*background: rgba(0, 180, 100, .3);*/
}
.bunny div, .bunny span{
    position: absolute;
}
/* 兔兔主体， 定位原点 */
.bunny .body{
    width: 90px;
    height: 90px;
    left: 15px;
    bottom: 20px;
    background-color: #FAFAFA;
    border-radius: 50% 50% 50% 50%/60% 60% 40% 50%;
    box-shadow: inset 10px -6px 10px rgba(0, 0, 0, 0.1);
    animation: upsideDown-bunny 1s infinite;
}
/* 兔兔耳朵 */
.bunny .ear{
    width: 20px;
    height: 80px;
    top: -67px;
    left: 18px;
    background: #FAFAFA;
    border-radius: 50% 80%;
    box-shadow: inset 3px -3px 3px rgba(0, 0, 0, 0.1);
    transform-origin: center bottom;
    animation: ears-bunny 2s infinite;
}
.bunny .ear.right{
    left: 50px;
    border-radius: 90% 50%;
}
.bunny .ear span{
    width: 10px;
    height: 60px;
    top: 15px;
    left: 5px;
    border-radius: 50% 80%;
    background: #FED7E4;
}
.bunny .ear.right span{
    border-radius: 90% 50%;
}
/* 兔兔眼睛 */
.bunny .eye{
    width: 20px;
    height: 25px;
    top: 35px;
    left: 20px;
    border-radius: 50%;
    background: radial-gradient(at 50% 50%, #FFFFFF 25%, #333333 30%, #666666);
    animation: eyes-bunny 1.5s infinite;
}
.bunny .eye.right{
    left: 55px;
}
/* 兔兔小红晕 */
.bunny .flush{
    width: 20px;
    height: 10px;
    top: 63px;
    left: 2px;
    border-radius: 70%;
    background: radial-gradient(at 50% 50%, #FF9292, #FFFFFF);
}
.bunny .flush span{
    width: 20px;
    height: 10px;
    right: -67px;
    border-radius: 70%;
    background: radial-gradient(at 50% 50%, #FF9292, #FFFFFF);
}
/* 兔兔小嘴 */
.bunny .mouth{
    width: 20px;
    height: 16px;
    left: 38px;
    bottom: 3px;
    border-radius: 30% 30% 100% 100%;
    background: radial-gradient(at 50% 100%, #FF9A9A 40%, #FEE9F0);
    animation: mouth-bunny 2s infinite;
}
/* 兔兔小手 */
.bunny .hand{
    width: 20px;
    height: 20px;
    bottom: -5px;
    left: 10px;
    border-radius: 50%;
    border: 1px solid #FFFFFF;
    box-shadow: inset 0 0 5px #FFFFFF;
    background: radial-gradient(at 50% 50%, #FF9292 20%, #EAEAEA 70%, #FFFFFF);
    animation: arm-bunny .5s ease-in-out infinite;
}
.bunny .hand.right{
    bottom: -5px;
    left: 60px;
    animation: arm-bunny .5s ease-in-out infinite .25s;
}
/* 阴影 */
.bunny .shadow{
    width: 50px;
    height: 10px;
    bottom: 3px;
    left: 35px;
    border-radius: 50%;
    background: radial-gradient(at center center, #666666, #AAAAAA);
    animation: shadow-bunny 1s infinite;
}

/* 动画 */
@keyframes upsideDown-bunny{
    50% {
        transform: translateY(-5px);
        border-radius: 50% 50% 50% 50%/60% 60% 40% 40%;
    }
}
@keyframes ears-bunny{
    25% {
        transform: rotateX(20deg) rotateY(-20deg) rotateZ(-20deg);
    }
    50% {
        transform: rotate(0deg);
    }
    75% {
        transform: rotateX(20deg) rotateY(-20deg) rotateZ(20deg);
    }
}
@keyframes eyes-bunny{
    50% {
        transform: scaleY(1.05);
    }
}
@keyframes mouth-bunny{
    50% {
        transform: scale(.6);
    }
}
@keyframes arm-bunny{
    33% {
        /*transform: scale(1.1);*/
        transform: translate(5px);
    }
    66% {
        /*transform: scale(.9);*/
        transform: translate(-5px);
    }
}
@keyframes shadow-bunny{
    50% {
        transform: scale(.7);
    }
}
</style>