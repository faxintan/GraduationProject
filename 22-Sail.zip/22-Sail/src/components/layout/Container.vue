<template>
    <div class="x-content">
        <router-view></router-view>        
    </div>
</template>

<script type="text/javascript">
export default {
    updated () {
        if (this.$el.scrollTop) {
            this.$el.scrollTop = 0
        }
    }
}
</script>

<style type="text/css">
.x-content{
    height: 100%;
    width: 100%;
    overflow-y: auto;
    background-color: #F6F9FD;
}
</style>