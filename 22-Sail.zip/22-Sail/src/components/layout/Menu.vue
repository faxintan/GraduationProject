<script type="text/javascript">
import MenuX from '../common/Menu1'
import MenuM from '../common/Menu2'

export default {
    functional: true,
    render: function (createElement, context) {
        if (context.parent._renderProxy.$isMobile) {
            return createElement(MenuM, context.data, context.children)
        } else {
            return createElement(MenuX, context.data, context.children)
        }
    }
}
</script>