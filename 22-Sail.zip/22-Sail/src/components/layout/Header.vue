<template>
    <div class="x-header">
        <h1 class="title">{{title}}</h1>
        <!-- <span class="m_hide">Copyright &copy; 22-Techno Inc. Owned By Louis_King</span> -->
        <span class="user" @click="dataCard=!dataCard">
            欢迎，{{$user.name + this.position[$user.position]||'请登录'}}
        </span>
        <x-datacard v-model="dataCard" :title="'个人信息'"
                :no="'退出登录'"
                @cancel="toLogin">
            <div class="name">{{$user.name || '请登录'}}</div>
            <div class="email">{{$user.email}}</div>
        </x-datacard>
    </div>
</template>

<script type="text/javascript">
import DataCard from '../common/DataCard'

export default {
    data () {
        return {dataCard: false}
    },
    computed: {
        title () {
            switch (this.$route.path) {
            case '/home': return '首  页'
            case '/status': return '个人信息'
            case '/major': return '专业信息'
            case '/course': return '课程信息'
            case '/grade': return '成绩信息'
            case '/field': return '专业录入'
            case '/manager': return '信息管理'
            case '/love': return '两小无猜'
            default: return '学生管理信息'
            }
        },
        position () {
            return {
                student: '同学',
                teacher: '老师',
                manager: '管理员'
            }
        }
    },
    methods: {
        toLogin () {
            window.sessionStorage.setItem('user', JSON.stringify({}))
            this.$router.push('/login')
        }
    },
    components: {
        'x-datacard': DataCard
    }
}
</script>

<style type="text/css">
.x-header{
    position: relative;
    height: 100%;
}
.x-header .title{
    display: inline-block;
    line-height: 50px;
    font-size: .72rem;
    font-weight: bold;
    color: #FFFFFF;
    letter-spacing: 3px;
}
.x-header .user{
    position: absolute;
    line-height: .5rem;
    right: .2rem;
    bottom: .2rem;
    font-size: .48rem;
    color: #5CB9DF;
    cursor: pointer;
    text-shadow: 0 0 2px #00FFFF;
}
.x-header .user:active{
    color: #089AD6;
}
.x-header .name{
    width: 100%;
    height: 2rem;
    line-height: 2rem;
    font-size: 1rem;
    font-weight: bold;
    color: #666666;
}
.x-header .email{
    width: 100%;
    font-size: .48rem;
    color: #666666;
}
</style>