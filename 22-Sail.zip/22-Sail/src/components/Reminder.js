import Vue from 'vue'
import Toast from './common/Toast'
import Loader from './common/Loader'
import Article from './common/Article'

const noop = function () {}

const _Loader = Vue.extend(Loader)
var _loader = null
var _loaderTimer = null

/* options = {status, messge, duration, callback} */
export function loader (options = {}) {
    if (!options.status) {
        _loader && (_loader.status = '')
        return
    }
    if (!_loader) {
        _loader = new _Loader({
            el: document.createElement('div')
        })
        document.body.appendChild(_loader.$el)
    }
    // set default callback width noop function
    options.callback = options.callback || noop
    _loader.$off('leave')
    _loader.$once('leave', () => {
        options.callback()
    })
    _loaderTimer && clearTimeout(_loaderTimer)
    if (options.duration > 0) {
        _loaderTimer = setTimeout(() => {
            _loader.status = ''
        }, options.duration)
    }
    _loader.message = options.message || ''
    // update at once everytime asign a new value
    Vue.nextTick(() => {
        _loader.status = options.status
    })
}

const _Toast = Vue.extend(Toast)
var _toast = null

/* options = {text, comfirm, cancel} */
export function toast (options = {}) {
    if (!options.text) {
        return
    }
    if (!_toast) {
        _toast = new _Toast({
            el: document.createElement('div')
        })
        document.body.appendChild(_toast.$el)
    }
    options.comfirm = options.comfirm || noop
    options.cancel = options.cancel || noop
    _toast.$once('comfirm', () => {
        options.comfirm()
    })
    _toast.$once('cancel', () => {
        options.cancel()
    })
    Vue.nextTick(() => {
        _toast.text = options.text
    })
}

const _Article = Vue.extend(Article)
var _article

/* article = {title, content, date} */
export function showArticle (article = {}) {
    var art = article
    if (!art.title || !art.content) {
        return
    }
    if (!_article) {
        _article = new _Article({
            el: document.createElement('div')
        })
        document.body.appendChild(_article.$el)
    }
    _article.$on('close', () => {
        art = {}
        _article.article = {}
    })
    Vue.nextTick(() => {
        _article.article = art
    })
}
