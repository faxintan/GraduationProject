<!-- <template>
    <div class="x-textarea">
        <div class="e_content" contenteditable="true"></div>
        <div class="e_title"><slot></slot></div>
    </div>
</template>

<style type="text/css">
.x-textarea{
    position: relative;
    margin: .8rem auto;
    width: 100%;
}
.x-textarea .e_title{
    position: absolute;
    width: 4rem;
    height: 1.5rem;
    line-height: 1rem;
    color: #FFFFFF;
    top: 3px;
    left: 3px;
    letter-spacing: 2px;
    font-size: .6rem;
    font-weight: bolder;
    text-align: center;
    background-color: #CCCCCC;
    text-shadow: 2px 3px 5px rgba(0, 0, 0, 0.3);
}
.x-textarea .e_title:after{
    position: absolute;
    content: '';
    bottom: 0;
    left: 0;
    border-bottom: .4rem solid #F6F9FD;
    border-left: 2rem solid transparent;
    border-right: 2rem solid transparent;
}
.x-textarea .e_content{
    padding: 2rem .4rem .4rem;
    width: 100%;
    min-height: 6rem;
    font-size: .56rem;
    text-indent: 1.12rem;
    word-wrap: break-word;
    overflow-x: hidden;
    border: 1px solid #B9C1CA;
}
.x-textarea .e_content:focus{
    border: 3px solid #82C7E4;
    box-shadow:0 0 5px rgba(81, 203, 238, 1);
}
.x-textarea .e_content:focus + .e_title{
    background: linear-gradient(to top left, #58B8E0, white);
}
</style> -->