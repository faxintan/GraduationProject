<!-- <template>
    <span class="x-radio">
        <input class="e_input__radio"
               type="radio"
               :id="id"
               :name="name"
               :checked="checked"
               :disabled="disabled">
        <label class="e_label" :for="id"><slot></slot></label>
    </span>
</template>

<script type="text/javascript">
export default {
    props: {
        id: {
            type: String
        },
        name: {
            type: String
        },
        checked: {
            type: Boolean,
            default: false
        },
        disabled: {
            type: Boolean,
            default: false
        }
    }
}
</script>

<style type="text/css">
.x-radio{
    margin-left: .6rem;
    line-height: .32rem;
    font-size: .56rem;
}
.x-radio .e_input__radio{
    font-family: 'icomoon' !important;
    appearance: none;
}
.x-radio .e_label{
    color: #333333;
}
.x-radio .e_input__radio:before{
    display: inline-block;
    margin-right: .1rem;
    content: '';
    width: .56rem;
    height: .56rem;
    border: 1px solid #CCCCCC;
    border-radius: 50%;
    overflow: hidden;
}
.x-radio .e_input__radio:checked:before{
    border: 1px solid transparent;
}
.x-radio .e_input__radio:active:before,
.x-radio .e_input__radio:checked:before{
    content: '\ea52';
    color: #89EB78;
    font-size: .56rem;
}
.x-radio .e_input__radio:disabled:before{
    display: inline-block;
    content: '';
    width: .56rem;
    height: .56rem;
    background: linear-gradient(to top, #CCCCCC, #EEEEEE);
    border: 1px solid #CCCCCC;
    border-radius: 50%;
}
</style> -->