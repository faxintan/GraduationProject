<!-- <template>
    <span class="x-checkbox">
        <input class="e_input__checkbox"
               type="checkbox"
               :id="id"
               :name="name"
               :checked="checked"
               :disabled="disabled">
        <label class="e_label" :for="id"><slot></slot></label>
    </span>
</template>

<script type="text/javascript">
export default {
    props: {
        id: {
            type: String
        },
        name: {
            type: String
        },
        checked: {
            type: Boolean
        },
        disabled: {
            type: Boolean
        }
    }
}
</script>

<style type="text/css">
.x-checkbox{
    margin-left: .4rem;
    font-size: .56rem;
}
.x-checkbox .e_input__checkbox{
    font-family: 'icomoon' !important;
    appearance: none;
}
.x-checkbox .e_label{
    color: #333333;
}
.x-checkbox .e_input__checkbox:before{
    display: inline-block;
    content: '';
    width: .56rem;
    height: .56rem;
    border: 1px solid #CCCCCC;
    border-radius: 3px;
    overflow: hidden;
}
.x-checkbox .e_input__checkbox:checked:before{
    border: 1px solid transparent;
}
.x-checkbox .e_input__checkbox:active:before,
.x-checkbox .e_input__checkbox:checked:before{
    content: '\ea52';
    color: #666666;
    font-size: .56rem;
}
.x-checkbox .input__checkbox:disabled:before{
    display: inline-block;
    content: ' ';
    width: .56rem;
    height: .56rem;
    background: linear-gradient(to top, #CCCCCC, #EEEEEE);
    border: 1px solid #CCCCCC;
    border-radius: 3px;
}
</style> -->