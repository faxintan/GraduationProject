<template>
    <span class="x-icon-input">
        <input class="e_input__field"
               :id="id"
               :type="type"
               :placeholder="placeholder"
               :value="value"
               @change="changeValue">
        <label class="e_input__label" :for="id">
            <span class="e_input__label-content icon-user-tie"></span>
        </label>
    </span>
</template>

<script type="text/javascript">
export default {
    props: {
        type: {
            type: String,
            default: 'text'
        },
        id: {
            type: String
        },
        placeholder: {
            type: String
        },
        value: {
        }
    },
    methods: {
        changeValue (e) {
            this.$emit('input', e.target.value)
        }
    }
}
</script>

<style type="text/css">
.x-icon-input{
    display: flex;
    flex-flow: row-reverse nowrap;
    justify-content: center;
    margin: 0 auto .4rem;
    width: 100%;
    max-width: 13rem;
}
.x-icon-input .e_input__field{
    flex: 1 1 auto;
    padding-left: .4rem;
    height: 1.6rem;
    line-height: 1.6rem;
    border: 1px solid #ECECEC;
}
.x-icon-input .e_input__label{
    flex: 0 0 auto;
    width: 2.4rem;
    height: 1.6rem;
    line-height: 1.8rem;
    text-align: center;
    font-size: .72rem;
    color: white;
    background-color: #EEEEEE;
}
.x-icon-input .e_input__label-content{
    display: inline-block;
    font-size: .8rem;
    color: #666666;
}
.x-icon-input .e_input__label .e_input__label-content{
    transition: all .4s;
}
.x-icon-input .e_input__field:focus{
    border: 1px solid #00FFFF;
    border-left: none;
    box-shadow: inset 0 0 5px #00FFFF;
}
.x-icon-input .e_input__field:focus + .e_input__label{
    background-color: #00FFFF;
}
.x-icon-input .e_input__field:focus + .e_input__label .e_input__label-content{
    color: white;
    transform: scale(1.2);
}
/*发光效果*/
.x-icon-input .e_input__field:focus,
.x-icon-input .e_input__field:focus + .e_input__label{
    box-shadow:0 0 5px rgba(81, 203, 238, 1);
}
</style>