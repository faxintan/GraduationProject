<template>
    <div class="x-label-input">
        <input class="e_input__field"
               :value="value"
               :type="type"
               :required="required"
               :placeholder="placeholder"
               @change="changeValue"/>
        <div class="e_input__label"
             :class="{'warn_color': required, 'disabled': inValid}"><slot></slot></div>
    </div>
</template>

<script type="text/javascript">
export default {
    props: {
        type: {
            type: String,
            default: 'text'
        },
        required: {
            type: Boolean
        },
        placeholder: {
            type: String
        },
        value: null
    },
    data () {
        return {
            inValid: false
        }
    },
    methods: {
        changeValue (e) {
            if (!e.target.value && this.required) {
                this.inValid = true
            } else {
                this.inValid = false
            }
            this.$emit('input', e.target.value)
        }
    }
}
</script>

<style type="text/css">
.x-label-input{
    position: relative;
    display: flex;
    flex-flow: row-reverse nowrap;
    justify-content: flex-end;
    margin: 0 auto .3rem;
    width: 100%;
    max-width: 13rem;
    height: 1.8rem;
    line-height: 1.8rem;
    overflow: hidden;
    cursor: text;
}
.x-label-input .e_input__label{
    padding: 0 .4rem 0 .2rem;
    min-width: 2.2rem;
    height: 1.8rem;
    font-size: .6rem;
    color: #666666;
    vertical-align: top;
    letter-spacing: 1px;
}
.x-label-input .e_input__field{
    flex: 1 1 auto;
    width: 1rem;
    height: 1.8rem;
    font-size: .6rem;
    color: #999999;
    border: none;
    background-color: transparent;
}
.x-label-input .e_input__label:before,
.x-label-input .e_input__label:after{
    content: '';
    position: absolute;
    width: 100%;
    left: 0;
    bottom: 0;
    border-bottom: 1px solid #B9C1CA;
}
.x-label-input .e_input__label:after{
    left: -100%;
    bottom: -1px;
    border-bottom: 2px solid #00FFFF;
    transition: left .3s ease-in-out;
}
.x-label-input .warn_color:after{
    border-bottom: 2px solid #E8937C;
}
.x-label-input .disabled:before{
    bottom: -1px;
    border-bottom: 2px solid #E8937C;
}
.x-label-input .e_input__field:focus + .e_input__label:after{
    left: 0px;
    box-shadow:0 0 2px #00FFFF;
}
.x-label-input .e_input__field:focus + .warn_color:after{
    box-shadow: 0px 0px 5px rgba(232, 147, 124, 1);
}
</style>