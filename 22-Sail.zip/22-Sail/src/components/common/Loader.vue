<template>
    <div class="x-loader" v-if="show">
        <div class="e_mask" v-if="!message"></div>
        <div class="e_message" v-if="status==='tips'&&message">
            <span>{{message}}</span>
        </div>
        <div class="e_loader" v-else>
            <i></i><i></i>
        </div>
    </div>
</template>

<script type="text/javascript">
export default {
    props: {
        status: '',
        message: ''
    },
    computed: {
        show () {
            if (this.status === 'success') {
                if (this.message) {
                    this.status = 'tips'
                    setTimeout(() => {
                        this.status = ''
                        this.$emit('leave')
                    }, 1000)
                } else {
                    this.status = ''
                    this.$emit('leave')
                }
            }
            return !!this.status
        }
    }
}
</script>

<style type="text/css">
.x-loader{
    position: fixed;
    margin: auto;
    height: 20px;
    width: 20px;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 150;
}
.x-loader .e_mask{
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    opacity: .3;
    z-index: 151;
    background: #CCCCCC;
}
.x-loader .e_message{
    position: fixed;
    margin: auto;
    height: 3rem;
    top: 0;
    right: 0;
    left: 0;
    bottom: 0;
    text-align: center;
}
.x-loader .e_message span{
    display: inline-block;
    padding: 0 10px;
    height: 3rem;
    line-height: 3rem;
    z-index: 152;
    color: #FFFFFF;
    font-size: .72rem;
    border-radius: .5rem;
    background: rgba(0, 0, 0, .5);    
}
.x-loader .e_loader{
    position: fixed;
    margin: auto;
    height: 20px;
    width: 20px;
    animation: spin 1.5s linear infinite;
}
.x-loader i{
    position: absolute;
    display: block;
    height: 20px;
    width: 20px;
    border-radius: 50%;
}
.x-loader i:before,
.x-loader i:after{
    position: absolute;
    display: block;
    content: '';
    height: inherit;
    width: inherit;
    border-radius: inherit;
}
.x-loader i:first-child:before{
    background-color: rgba(52, 149, 221, 0.9);
    animation: rotate-top-left 1.5s linear infinite;
}
.x-loader i:first-child:after{
    background: rgba(225, 73, 44, 0.9);
    animation: rotate-top-right 1.5s linear infinite;
}
.x-loader i:last-child:before{
    background: rgba(249, 206, 43, 0.9);
    animation: rotate-bottom-left 1.5s linear infinite;
}
.x-loader i:last-child:after{
    background-color: rgba(0, 153, 117, 0.9);
    animation: rotate-bottom-right 1.5s linear infinite;
}
@keyframes spin{
    0% { transform: rotate(0deg); }
    50% { transform: rotate(-180deg); }
    100% { transform: rotate(-360deg); }
}
@keyframes rotate-top-right{
    0% { transform: rotate(0deg); }
    50% {
        transform: rotate(-180deg);
        transform-origin: 20% 20%;
    }
    100% { transform: rotate(-360deg); }
}
@keyframes rotate-top-left {
    0% { transform: rotate(0deg); }
    50% {
        transform: rotate(180deg);
        transform-origin: 80% 20%;
    }
    100% { transform: rotate(360deg); }
}
@keyframes rotate-bottom-right{
    0% { transform: rotate(0deg); }
    50% {
        transform: rotate(-180deg);
        transform-origin: 80% 80%;
    }
    100% { transform: rotate(-360deg); }
}
@keyframes rotate-bottom-left{
    0% { transform: rotate(0deg); }
    50% {
        transform: rotate(180deg);
        transform-origin: 20% 80%;
    }
    100% { transform: rotate(360deg); }
}
</style>