<template>
    <div class="x-data-card" v-if="show" @keyup.enter="confirm">
        <div class="e_card_mask"></div>
        <div class="e_card_wrapper">
            <div class="e_card_panel m_expand">
                <div class="e_card_top">
                    <div class="e_card_title">{{title}}</div>
                    <span class="e_card_close" @click="close">&times;</span>
                    <div class="e_portrait"></div>
                </div>
                <div class="e_card_content"><slot></slot></div>
                <div class="e_card_bottom" v-if="yes||no">
                    <div class="x-btn blue" v-if="yes"
                         style="margin:.2rem"
                         @click="confirm">{{yes}}</div>
                    <div class="x-btn" v-if="no"
                         style="margin:.2rem"
                         @click="cancel">{{no}}</div>
                </div>
            </div>
        </div>
    </div>
</template>

<script type="text/javascript">
export default {
    props: {
        title: {
            type: String
        },
        yes: {
            type: String
        },
        no: {
            type: String
        },
        value: {
            type: Boolean
        }
    },
    computed: {
        show () {
            return this.value
        }
    },
    methods: {
        close () {
            this.$emit('input', false)
        },
        confirm () {
            this.$emit('confirm')
            // this.$emit('input', false)
        },
        cancel () {
            this.$emit('cancel')
            // this.$emit('input', false)
        }
    }
}
</script>

<style type="text/css">
.x-data-card{
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 100;
    text-align: center;
    overflow: auto;
}
.x-data-card .e_card_mask{
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, .1);
}
.x-data-card .e_card_wrapper{
    display: flex;
    align-items: center;
    position: fixed;
    margin: auto;
    padding: 0 .5rem;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 103;
}
.x-data-card .e_card_panel{
    margin: auto;
    width: 18rem;
}
.x-data-card .e_card_top{
    position: relative;
    padding: .4rem;
    height: 4.5rem;
    color: #FFFFFF;
    font-size: .72rem;
    border-top-left-radius: .2rem;
    border-top-right-radius: .2rem;
    background-color: #61C0E7;
    z-index: 100;
}
.x-data-card .e_card_title{
    height: 1rem;
    line-height: 1rem;
}
.x-data-card .e_card_close{
    position: absolute;
    top: .4rem;
    right: .4rem;
    cursor: pointer;
}
.x-data-card .e_card_close:active{
    color: #CCCCCC;
}
.x-data-card .e_portrait{
    display: inline-block;
    margin-top: 1rem;
    width: 4rem;
    height: 4rem;
    border-radius: 50%;
    border: 2px solid #EAEAEA;
    background: url('../../assets/logo.png') center no-repeat,
                linear-gradient(to bottom, white 45%, #2CB0E6);
    background-size: contain;
}
.x-data-card .e_card_content{
    padding: .2rem .5rem;
    max-height: 12rem;
    border-top: 2rem solid #FFFFFF;
    border-bottom: .5rem solid #FFFFFF;
    overflow: auto;
    background-color: #FFFFFF;
}
.x-data-card .e_card_bottom{
    background-color: #FFFFFF;
}
</style>