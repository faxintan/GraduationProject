<template>
    <div class="x-menu" :style="{'max-width':show?'9rem':'0px'}">
        <div class="e_menu_container" :class="{hidden:!show}">
            <div class="e_menu_portrait">
                <div class="e_menu_mask" @click="dataCard=true">
                    <div class="e_photo"></div>
                </div>
            </div>
            <ul class="e_menu_items">
                <router-link tag="li" to="/home">
                    <span class="icon-home"></span> 首   页
                </router-link>
                <router-link tag="li" to="/status" v-if="$user.position!=='manager'">
                    <span class="icon-profile"></span> 个人信息
                </router-link>
                <router-link tag="li" to="/major" v-if="$user.position!=='manager'">
                    <span class="icon-svg"></span> 专业信息
                </router-link>
                <router-link tag="li" to="/course">
                    <span class="icon-books"></span> 课程信息
                </router-link>
                <router-link tag="li" to="/grade" v-if="$user.position!=='manager'">
                    <span class="icon-spell-check"></span> 成绩信息
                </router-link>
                <router-link tag="li" to="/field" v-if="$user.position==='manager'">
                    <span class="icon-paypal"></span> 专业录入
                </router-link>
                <router-link tag="li" to="/system" v-if="$user.position==='manager'">
                    <span class="icon-cog"></span> 信息管理
                </router-link>
                <router-link tag="li" to="/love" v-if="$user.name==='陈淑仪'">
                    <span class="icon-heart"></span> 两小无猜
                </router-link>
            </ul>
        </div>
        <div class="e_btn" @click="show=!show">
            <div class="e_triangle" :class="{'e_show':show,'e_hide':!show}"></div>
        </div>
        <x-datacard v-model="dataCard" :title="'个人信息'"
                :no="'退出登录'"
                @cancel="toLogin">
            <div class="name">{{$user.name || '请登录'}}</div>
            <div class="email">{{$user.email}}</div>
        </x-datacard>
    </div>
</template>

<script type="text/javascript">
import DataCard from './DataCard'

export default {
    data () {
        return {
            show: false,
            dataCard: false
        }
    },
    methods: {
        toLogin () {
            window.sessionStorage.setItem('user', JSON.stringify({}))
            this.$router.push('/login')
        }
    },
    components: {
        'x-datacard': DataCard
    }
}
</script>

<style type="text/javascript">
.x-menu{
    position: relative;
    max-width: 9rem;
    height: 100%;
    border-left: 1px solid #686F79;
    z-index: 99;
    transition: max-width .5s ease-out;
}
.x-menu .e_menu_container{
    height: 100%;
    background-color: #EEF1F6;
    transition: opacity .3s ease-out;
}
.x-menu .hidden{
    opacity: 0;
    pointer-events: none;
}
.x-menu .e_menu_portrait{
    display: flex;
    justify-content: center;
    align-items: center;
    height: 5rem;
}
.x-menu .e_menu_mask{
    position: relative;
    width: 3rem;
    height: 3rem;
}
.x-menu .e_menu_mask:after{
    position: absolute;
    content: '';
    height: 3rem;
    width: 3rem;
    right: 0;
    opacity: .6;
    border-radius: 50%;
    border: 1px solid #FFFFFF;
    background-color: #E2E5EA;
}
.x-menu .e_menu_mask:hover:after{
    opacity: 0;
}
.x-menu .e_menu_mask:active:after{
    opacity: .2;
    background-color: #666666;
}
.x-menu .e_photo{
    display: inline-block;
    width: 3rem;
    height: 3rem;
    border-radius: 50%;
    border: 1px solid #FFFFFF;
    background: url('../../assets/logo.png') center no-repeat;
    background-size: contain;
}
.x-menu li{
    cursor: pointer;
    padding-left: 1.8rem;
    padding-right: 2.2rem;
    height: 2rem;
    line-height: 2rem;
    text-align: left;
    border-radius: 5px;
    letter-spacing: 2px;
    text-shadow: 1px 1px 3px #999999;
    white-space: nowrap;
    overflow: hidden;
}
.x-menu li:hover{
    background-color: #B3B9C2;
    background: linear-gradient(to top, #EAEAEA, #B3B9C2);
}
.x-menu .e_btn{
    position: absolute;
    border-left: .9rem solid #D3D9E4;
    border-top: 1.2rem solid transparent;
    border-bottom: 1.2rem solid transparent;
    height: 4rem;
    width: 0;
    top: 30%;
    right: -.9rem;
    z-index: 100;
}
.x-menu .e_btn:active{
    border-left-color: #B7BECB;
}
.x-menu .e_triangle{
    position: absolute;
    width: 0;
    height: 0;
    right: .25rem;
    top: -.2rem;
    transition: border .5s ease-in;
}
.x-menu .e_show{
    border-top: 1rem solid transparent;
    border-bottom: 1rem solid transparent;
    border-right: .5rem solid #686F79;
}
.x-menu .e_hide{
    border-top: 1rem solid transparent;
    border-bottom: 1rem solid transparent;
    border-left: .5rem solid #686F79;
}
.x-menu .name{
    width: 100%;
    height: 2rem;
    line-height: 2rem;
    font-size: 1rem;
    font-weight: bold;
    color: #666666;
}
.x-menu .email{
    width: 100%;
    font-size: .48rem;
    color: #666666;
}
</style>