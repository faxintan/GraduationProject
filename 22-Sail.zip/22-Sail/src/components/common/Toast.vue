<template>
    <div class="x-dialog" v-if="show">
        <div class="e_dialog_mask"></div>
        <div class="e_dialog">
            <div class="e_dialog_content">{{text}}</div>
            <div class="e_dialog_footer">
                <div class="x-btn blue" @click="comfirm">确 定</div>
                <div class="x-btn" @click="cancel">取 消</div>
            </div>
        </div>
    </div>
</template>

<script type="text/javascript">
export default {
    props: ['text'],
    computed: {
        show () {
            return !!this.text
        }
    },
    methods: {
        comfirm () {
            this.text = ''
            this.$emit('comfirm')
        },
        cancel () {
            this.text = ''
            this.$emit('cancel')
        }
    }
}
</script>

<style type="text/css">
.x-dialog .e_dialog_mask{
    position: fixed;
    height: 100%;
    width: 100%;
    top: 0;
    left: 0;
    opacity: 0.5;
    z-index: 100;
    background-color: #666666;
}
.x-dialog .e_dialog{
    position: fixed;
    margin: auto;
    width: 10rem;
    height: 6.6rem;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    color: #EEEEEE;
    z-index: 101;
    border-radius: 5px;
}
.x-dialog .e_dialog_content{
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    padding: .8rem;
    height: 5rem;
    font-size: .72rem;
    text-align: center;
    color: #333333;
    border: 1px solid #CCCCCC;
    background-color: #FFFFFF;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
}
.x-dialog .e_dialog_footer{
    padding-top: .2rem;
    height: 1.6rem;
    line-height: 1.6rem;
    text-align: center;
    border: 1px solid #CCCCCC;
    border-top: none;
    border-bottom-left-radius: 3px;
    border-bottom-right-radius: 3px;
    background-color: #EFEFEF;
}
.x-dialog .x-btn{
    margin: 0 .2rem;
}
</style>