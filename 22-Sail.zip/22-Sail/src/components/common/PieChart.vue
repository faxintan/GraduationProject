<template>
    <div class="x-circle">
        <div class="e_container" :style="wrapper">
            <div class="e_right_outter">
                <div class="e_right_inner" :style="right"></div>
            </div>
            <div class="e_left_outter">
                <div class="e_left_inner" :style="left"></div>
            </div>
            <div class="e_outter" :style="{
                'border-color': this.config.outterA,
                'border-width': this.config.round}"></div>
        </div>
        <div class="e_label1" :style="{'border-color':config.outterA}">{{config.label1+' '+percent}}%</div>
        <div class="e_label2" :style="{'border-color':config.outterB}">{{config.label2+' '+(100-percent)}}%</div>
    </div>
</template>

<script type="text/javascript">
export default {
    props: {
        percent: {
            type: Number,
            default: 30,
            validator: function (value) {
                return value <= 100
            }
        },
        config: {
            type: Object,
            default: function () {
                return {}
            }
        }
    },
    data () {
        var initLeft = this.percent >= 50 ? 180 : this.percent * 3.6
        var initRight = this.percent > 50 ? (this.percent - 50) * 3.6 : 0
        return {
            left: {
                'border-color': this.config.outterB,
                'border-width': this.config.round,
                transform: 'rotate(' + initLeft + 'deg)',
                transition: 'transform 1s linear'
            },
            right: {
                'border-color': this.config.outterB,
                'border-width': this.config.round,
                transform: 'rotate(' + initRight + 'deg)',
                transition: 'transform 1s linear 1s'
            },
            wrapper: {
                width: this.config.radius,
                height: this.config.radius,
                background: this.config.inner
            }
        }
    },
    watch: {
        percent (newVal, oldVal) {
            var vm = this
            function setDelay (left, right) {
                vm.left['transition'] = 'transform 1s linear ' + left + 's'
                vm.right['transition'] = 'transform 1s linear ' + right + 's'
            }
            if (newVal < oldVal) {
                if (newVal > 50) {
                    this.left['transform'] = 'rotate(180deg)'
                    this.right['transform'] = 'rotate(' + (newVal - 50) * 3.6 + 'deg)'
                    setDelay(0, 0)
                } else {
                    this.left['transform'] = 'rotate(' + newVal * 3.6 + 'deg)'
                    this.right['transform'] = 'rotate(0deg)'
                    if (oldVal > 50) {
                        setDelay(1, 0)
                    } else {
                        setDelay(0, 0)
                    }
                }
            } else {
                if (newVal > 50) {
                    this.left['transform'] = 'rotate(180deg)'
                    this.right['transform'] = 'rotate(' + (newVal - 50) * 3.6 + 'deg)'
                    if (oldVal >= 50) {
                        setDelay(0, 0)
                    } else {
                        setDelay(0, 1)
                    }
                } else {
                    this.left['transform'] = 'rotate(' + newVal * 3.6 + 'deg)'
                    this.right['transform'] = 'rotate(0deg)'
                    setDelay(0, 0)
                }
            }
        }
    }
}
</script>

<style type="text/css">
.x-circle{
    display: inline-block;
    text-align: center;
}
.x-circle .e_container{
    margin: auto;
    width: 5rem;
    height: 5rem;
    border-radius: 50%;
    background: linear-gradient(to top left, #BBBBBB, white);
}
.x-circle .e_outter{
    width: 100%;
    height: 100%;
    border-radius: 50%;
    border: .4rem solid #00FF00;
}
.x-circle .e_right_outter{
    display: inline-block;
    float: left;
    width: 50%;
    height: 100%;
    overflow: hidden;
}
.x-circle .e_right_inner{
    width: 100%;
    height: 100%;
    border: .4rem solid #00FFFF;
    border-right: none;
    border-top-left-radius: 100% 50%;
    border-bottom-left-radius: 100% 50%;
    transform-origin: 100% 50%;
}
.x-circle .e_left_outter{
    display: inline-block;
    float: right;
    width: 50%;
    height: 100%;
    overflow: hidden;
}
.x-circle .e_left_inner{
    float: right;
    width: 100%;
    height: 100%;
    border: .4rem solid #00FFFF;
    border-left: none;
    border-top-right-radius: 100% 50%;
    border-bottom-right-radius: 100% 50%;
    transform-origin: 0 50%;
}
.x-circle .e_label1, .x-circle .e_label2{
    display: inline-block;
    margin-top: .4rem;
    padding-left: .2rem;
    padding-right: .2rem;
    height: .56rem;
    line-height: .56rem;
    border-left: .56rem solid #00FFFF;
}
.x-circle .e_label2{
    border-left: .56rem solid #00FF00;
}
</style>
