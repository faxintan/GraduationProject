<template>
    <div class="m-menu">
        <div class="e_menu_container">
            <div class="e_menu_btn"
                 :class="{'e_active':open}"
                 @click="showMenu"></div>
            <ul class="e_menu_items" :class="{'e_open':open}">
                <router-link class="item" to="/home">
                    <span class="icon-home"></span>
                </router-link>
                <router-link class="item" to="/status" v-if="$user.position!=='manager'">
                    <span class="icon-profile"></span>
                </router-link>
                <router-link class="item" to="/major" v-if="$user.position!=='manager'">
                    <span class="icon-svg"></span>
                </router-link>
                <router-link class="item" to="/course">
                    <span class="icon-books"></span>
                </router-link>
                <router-link class="item" to="/grade" v-if="$user.position!=='manager'">
                    <span class="icon-spell-check"></span>
                </router-link>
                <router-link class="item" to="/field" v-if="$user.position==='manager'">
                    <span class="icon-paypal"></span>
                </router-link>
                <router-link class="item" to="/system" v-if="$user.position==='manager'">
                    <span class="icon-cog"></span>
                </router-link>
                <router-link class="item" to="/love" v-if="$user.name==='陈淑仪'">
                    <span class="icon-heart"></span>
                </router-link>
            </ul>
        </div>
    </div>
</template>

<script type="text/javascript">
export default {
    data () {
        return {
            open: false
        }
    },
    methods: {
        showMenu () {
            this.open = !this.open
        }
    }
}
</script>

<style type="text/css">
.m-menu{
    position: fixed;
    width: 100%;
    bottom: 1rem;
    z-index: 100;  
}
.m-menu .e_menu_container{
    margin: 0 auto;
    width: 96%;
    text-align: center;
    text-transform: uppercase;
}
.m-menu .e_menu_btn,.m-menu .e_menu_items{
    transition: all 1s cubic-bezier(.87,-.41,.19,1.44);
}
.m-menu .e_menu_btn{
    position: relative;
    width: 2.5rem;
    height: 2.5rem;
    line-height: 2.5rem;
    left: calc(50% - 1.25rem);
    border-radius: 50%;
    background: url('../../assets/logo.png') no-repeat center,
                linear-gradient(to top left, #BBBBBB, white);
    background-size: contain;
    box-shadow: 0px 0px 15px #CCCCCC;
}
.m-menu .e_menu_btn.e_active{
    left: 0;
    transform: rotate(-90deg);
}
.m-menu .e_menu_items{
    box-sizing: content-box;
    margin: -2.5rem 0 0 calc(50% - 1.25rem);
    padding: 0.5rem .28rem .28rem 2rem;
    list-style: none;
    width: 0%;
    height: 1.6rem;
    line-height: 1.6rem;
    border-radius: 1.6rem;
    overflow: hidden;
    background-color: #EEEEEE;
    box-shadow: 1px 1px 1px 1px #DCDCDC;
}
.m-menu .e_menu_items.e_open{
    margin: -2.5rem 0 0 0;
    width: 85%;
}
.m-menu .e_menu_items .item{
    display: none;
    width: 1%;
    color: #3AB09E;
}
.m-menu .e_menu_items.e_open .item{
    display: inline-block;
    width: 15%;
    font-size: 1rem;
}
.m-menu .e_menu_items.e_open .item:hover{color:#20A0FF;}
</style>