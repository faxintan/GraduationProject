<template>
    <div class="x-panel">
        <div class="e_panel_title">{{title}}<slot name="icon"></slot></div>
        <div class="e_panel_content"><slot></slot></div>
    </div>
</template>

<script type="text/javascript">
export default {
    props: {
        title: {
            type: String,
            default: '标 题'
        }
    }
}
</script>

<style type="text/css">
.x-panel{
    margin: .4rem;
    cursor: default;
    box-shadow: 2px 3px 10px #999999;
}
.x-panel .e_panel_title{
    padding-left: .4rem;
    height: 1.2rem;
    line-height: 1.2rem;
    color: #333333;
    font-size: .56rem;
    font-weight: bold;
    letter-spacing: 3px;
    border-top-left-radius: 3px;
    border-top-right-radius: 3px;
    text-shadow: 2px 3px 3px #999999;
    background: linear-gradient(to top left, #EEEEEE, #FAFAFA);
}
.x-panel .e_panel_title span{
    display: inline-block;
    float: right;
    width: 1.5rem;
    height: 1.2rem;
    line-height: 1.2rem;
    text-align: center;
    cursor: pointer;
    color: #CCCCCC;
    text-shadow: none;
}
.x-panel .e_panel_title span:active{
    color: #333333;
    text-shadow: none;
}
.x-panel .e_panel_content{
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    /*align-items: center;*/
    padding: .4rem;
    font-size: 0.56rem;
    border: 1px solid #E8EBEB;
    background-color: #FFFFFF;
}
</style>