<template>
    <div class="x-article" v-if="show">
        <div class="e_article_container" :style="{'max-height':$isMobile?'100%':'15rem'}">
            <div class="e_article_title">{{article.title}}</div>
            <span class="e_article_close icon-cross" @click="close"></span>
            <div class="e_article_content" ref="article" @scroll="scroll">{{article.content}}</div>
            <div class="e_article_date" :style="{'background': 'radial-gradient(at 50% -50%, #AAAAAA, #FFFFFF '+more+'%)'}">
                {{article.date?article.date.substr(0,10):''}}</div>
            <span class="icon-quill"></span>
        </div>
    </div>
</template>

<script type="text/javascript">
export default {
    props: {
        article: {
            type: Object,
            default: function () {
                return {
                    title: '世界之最',
                    content: '唯我独爱，唯我独尊。',
                    date: '2017-06-15'
                }
            }
        }
    },
    data () {
        return {
            more: 0
        }
    },
    computed: {
        show () {
            return this.article.title && this.article.content
        }
    },
    methods: {
        scroll () {
            const article = this.$refs.article
            const scroll = article.scrollHeight - article.offsetHeight
            this.more = Math.min(scroll - article.scrollTop, 60)
        },
        close () {
            this.$emit('close')
        }
    },
    mounted () {
        const article = this.$refs.article
        const scroll = article.scrollHeight - article.offsetHeight
        this.more = Math.min(scroll - article.scrollTop, 60)
    }
}
</script>

<style type="text/css">
.x-article{
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    z-index: 100;
    background-color: rgba(0, 0, 0, .2);
}
.x-article .e_article_container{
    position: fixed;
    margin: auto;
    width: 95%;
    max-width: 25rem;
    height: 90%;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 101;
    border-radius: 5px;
    border: 5px solid #0582B4;
    background-color: #FFFFFF;
}
.x-article .e_article_title{
    height: 3rem;
    line-height: 3rem;
    font-size: .72rem;
    font-weight: bold;
    text-align: center;
    letter-spacing: 3px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.x-article .e_article_close{
    position: absolute;
    display: inline-block;
    width: 1rem;
    height: 1rem;
    line-height: 1rem;
    top: 0;
    right: 0;
    font-size: .48rem;
    text-align: center;
    color: #333333;
    border-radius: 50%;
    box-shadow: inset 0 0 5px #0582B4;
}
.x-article .e_article_close:hover{
    background: radial-gradient(at 50% 50%, #FFFFFF, #0582B4);
}
.x-article .e_article_close:active{
    background: radial-gradient(at 50% 50%, #FFFFFF, blue);
}
.x-article .e_article_content{
    padding: 0 .64rem;
    height: calc(100% - 4.8rem);
    line-height: 1rem;
    text-indent: 1.28rem;
    letter-spacing: 1px;
    overflow: auto;
}
.x-article .e_article_date{
    padding-right: .64rem;
    height: 1.8rem;
    line-height: 1.8rem;
    text-align: right;
    font-size: .64rem;
    border-top: 5px solid #FFFFFF;
}
.icon-quill{
    position: absolute;
    display: block;
    right: .5rem;
    bottom: 1rem;
    font-size: 8rem;
    color: #ECFDFD;
    z-index: -1;
}
</style>