<template>
    <div class="x-select" :class="{e_focus: active}" ref="select">{{options[key]||options['label']}}
        <span class="e_icon"
              :class="{e_active: active}"
              @click="active=!active"></span>
        <div class="e_options" :style="{
                width: maxLen*0.48+'rem',
                opacity:active?'1':'0',
                'pointer-events':active?'auto':'none'}">
            <div class="e_option" v-for="(val, key) in options"
                 @click="select(key)">
                 <span v-if="key !== 'label'">{{val}}</span>
             </div>
        </div>
    </div>
</template>

<script type="text/javascript">
export default {
    props: {
        value: {
            type: String
        },
        options: {
            type: Object,
            default: function () {
                return {one: '第一个'}
            }
        }
    },
    data () {
        var len = []
        for (let i = 0; i < this.options.length; i++) {
            len.push(this.options[i].replace(/[\u0391-\uFFE5]/g, 'aa').length)
        }
        return {
            active: false,
            key: this.value,
            maxLen: Math.max.apply(null, len)
        }
    },
    methods: {
        select (key) {
            this.key = key
            this.$emit('input', key)
            this.active = false
            this.$refs.select.scrollTop = 0
        }
    }
}
</script>

<style type="text/css">
.x-select{
    position: relative;
    display: inline-block;
    min-width: 4.6rem;
    max-width: 13rem;
    height: 1.2rem;
    line-height: 1.2rem;
    font-size: .56rem;
    text-align: center;
    text-indent: .4rem;
    color: #333333;
    vertical-align: top;
    border-radius: .6rem;
    box-shadow: inset 0 0 5px #CCCCCC;
    background-color: #FFFFFF;
    cursor: pointer;
}
.x-select.e_focus{
    border: 1px solid #00FFFF;
    box-shadow: inset 0 0 5px #00FFFF;
}
.x-select .e_icon{
    position: relative;
    display: inline-block;
    margin: .25rem .3rem .25rem;
    float: right;
    width: .7rem;
    height: .7rem;
    border: 1px solid #CCCCCC;
    border-radius: 50%;
    transition: transform .3s ease-out;
}
.x-select .e_icon:after{
    position: absolute;
    content: '';
    top: .13rem;
    right: .07rem;
    border-left: .25rem solid transparent;
    border-right: .25rem solid transparent;
    border-bottom: .3rem solid #CCCCCC;
}
.x-select .e_active{
    transform: rotate(-180deg);
    border-color: #00FFFF;
}
.x-select .e_active:after{
    border-bottom: .3rem solid #00FFFF;
}
.x-select .e_options{
    position: absolute;
    min-width: 100%;
    max-height: 5.5rem;
    top: 1.2rem;
    cursor: pointer;
    text-align: left;
    border: 1px solid #CCCCCC;
    box-shadow: inset 0 0 5px #CCCCCC;
    border-radius: 5px;
    background-color: #FFFFFF;
    overflow-x: hidden;
    overflow-y: scroll;
    z-index: 100;
    transition: opacity .3s ease-in;
}
.x-select .e_option{
    font-size: .48rem;
    padding-right: .5rem;
    border-bottom: 1px solid #CCCCCC;
}
/*.x-select .e_option:nth-child(even){
    background-color: #F0F0F0;
}*/
.x-select .e_option:hover{
    color: #FFFFFF;
    background-color: #65D7F3;
}
</style>