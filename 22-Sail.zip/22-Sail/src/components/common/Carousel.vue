<template>
    <div class="x-carousel" v-if="length" ref="carousel"
         @touchstart="start"
         @touchmove="move"
         @touchend="end">
        <div class="e_carousel_inside"
             :style="{transform:'translateX('+dx+'px)',width:100*length+'%'}">
            <slot></slot>
        </div>
    </div>
    <div class="e_carousel_inside" v-else>
        <slot></slot>
    </div>
</template>

<script type="text/javascript">
export default {
    props: {
        length: {type: Number, default: 3}
    },
    data () {
        return {
            x: 0,
            dx: 0,
            num: 0,
            width: 0
        }
    },
    methods: {
        start (e) {
            this.x = e.targetTouches[0].pageX
        },
        move (e) {
            const _touch = e.targetTouches[0]
            if (Math.abs(_touch.pageX - this.x) > 3) {
                e.preventDefault()
            }
            this.dx = _touch.pageX - this.x - this.width * this.num
        },
        end (e) {
            const _touch = e.changedTouches[0]
            const width = this.width
            const distance = _touch.pageX - this.x
            const len = this.length - 1
            if (distance > width / 3) {
                this.num = this.num <= 0 ? 0 : this.num - 1
                this.dx = -(this.width * this.num)
            } else {
                if (distance < -(width / 3)) {
                    this.num = this.num >= len ? len : this.num + 1
                    this.dx = -(this.width * this.num)
                } else {
                    this.dx = -(this.width * this.num)
                }
            }
        }
    },
    mounted () {
        if (this.length) {
            this.width = this.$refs.carousel.offsetWidth
        }
    }
}
</script>

<style type="text/css">
.x-carousel{
    position: relative;
    margin: .4rem 0;
    overflow: hidden;
}
.e_carousel_inside{
    display: flex;
    justify-content: space-around;
    align-items: stretch;
    width: 100%;
    transition: transform .3s ease-out;
}
</style>