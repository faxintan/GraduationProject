<template>
    <div class="x-dialog">
        <div class="e_dialog_mask" @click="close"></div>
        <div class="e_dialog">
            <div class="e_dialog_title" v-if="title">{{title}}
                <span @click="close">&times;</span>
            </div>
            <div class="e_dialog_content"><slot></slot></div>
            <div class="e_dialog_footer" v-if="footer">
                <div class="x-btn blue small">确 定</div>
                <div class="x-btn samll" @click.native="close">取 消</div>
            </div>
        </div>
    </div>
</template>

<script type="text/javascript">
export default {
    props: ['title', 'footer'],
    methods: {
        close () {
            this.$emit('show', false)
        }
    }
}
</script>

<style type="text/css">
.x-dialog .e_dialog_mask{
    position: fixed;
    height: 100%;
    width: 100%;
    top: 0;
    left: 0;
    opacity: 0.2;
    z-index: 100;
    background-color: #666666;
}
.x-dialog .e_dialog{
    position: fixed;
    margin: auto;
    height: 50%;
    width: 50%;
    min-width: 12rem;
    max-width: 18rem;
    min-height: 10rem;
    max-height: 16rem;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    color: #EEEEEE;
    z-index: 101;
    border-radius: 5px;
}
.x-dialog .e_dialog_title{
    padding: 0 .4rem;
    height: 1.2rem;
    line-height: 1.2rem;
    font-size: .56rem;
    font-weight: bold;
    letter-spacing: 3px;
    border-top-left-radius: 3px;
    border-top-right-radius: 3px;
    background: linear-gradient(to top left, #999999, #666666);
}
.x-dialog .e_dialog_title span{
    display: inline-block;
    float: right;
    line-height: 1.2rem;
    cursor: pointer;
    color: #555555;
}
.x-dialog .e_dialog_title span:hover{
    color: #CCCCCC;
}
.x-dialog .e_dialog_title span:active{
    color: #444444;
}
.x-dialog .e_dialog_content{
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    padding: .8rem 1.6rem;
    border: 1px solid #CCCCCC;
    background-color: #FFFFFF;
}
.x-dialog .e_dialog_footer{
    padding: 0 .4rem;
    height: 1.6rem;
    line-height: 1.4rem;
    text-align: right;
    border: 1px solid #CCCCCC;
    border-top: none;
    border-bottom-left-radius: 3px;
    border-bottom-right-radius: 3px;
    background-color: #EFEFEF;
}
</style>