<template>
<div class="x-search" :class="{active: active}" @keyup.enter="search">
    <div class="e_search_wrapper">
        <input type="text"
               v-model="text"
               class="e_search_input"
               placeholder="Type to search" />
        <div class="e_search_btn" @click="search">
            <div class="e_search_icon">
                <span class="icon-search"></span>
            </div>
        </div>
    </div>
    <div class="e_search_close" @click="close">
        <span class="icon-cross"></span>
    </div>
</div>
</template>

<script type="text/javascript">
export default {
    data () {
        return {
            active: false,
            text: ''
        }
    },
    methods: {
        search () {
            if (this.active) {
                this.$emit('input', this.text)
            } else {
                this.active = !this.active
            }
        },
        close () {
            this.active = !this.active
            this.$emit('input', '')
        }
    }
}
</script>

<style type="text/css">
.x-search{
    position: relative;
    display: inline-block;
    vertical-align: top;
}
.x-search .e_search_wrapper{
    position: relative;
    width: 1.2rem;
    height: 1.2rem;
    border-radius: 5px;
    background: rgba(255,255,255,0);
    overflow: hidden;
    transition: all .3s ease-in-out;
}
.x-search .e_search_input{
    position: absolute;
    padding: 0 1.2rem 0 .8rem;
    width: 100%;
    height: 1rem;
    line-height: 1rem;
    top: 0;
    left: 0;
    font-size: .48rem;
    font-weight: bold;
    color: white;
    opacity: 1;
    border: none;
    background: transparent;
    transform: translateY(1.2rem);
    transition: all .3s cubic-bezier(0.000, 0.105, 0.035, 1.570) .3s;
}
.x-search .e_search_btn{
    position: relative;
    float: right;
    width: 1.2rem;
    height: 1.2rem;
    line-height: 1.2rem;
    text-align: center;
    border-radius: .2rem;
    background-color: #FFFFFF;
    box-shadow: inset 0 0 5px #CCCCCC;
    z-index: 10;
    transition: all .3s ease-in-out;
}
.x-search .e_search_btn:active{
    background: radial-gradient(at 40% 30%, #FFFFFF, #00FFFF);
}
.x-search .e_search_icon{
    display: inline-block;
    width: .8rem;
    height: .8rem;
    line-height: .8rem;
    font-size: .64rem;
    color: #CCCCCC;
    transform: rotate(90deg);
    transition: all .4s cubic-bezier(0.650, -0.600, 0.240, 1.650);
}
/*展开后的样式*/
.x-search.active .e_search_wrapper{
    border-radius: .8rem;
    width: 10rem;
    background-color: rgba(50, 50, 50, 0.5);
    transition: all .5s cubic-bezier(0.000, 0.105, 0.035, 1.570);
}
.x-search.active .e_search_input{
    opacity: 1;
    transform: translateY(.15rem);
}
.x-search.active .e_search_btn{
    margin: .1rem;
    width: 1rem;
    height: 1rem;
    line-height: 1rem;
    border-radius: 50%;
    border: 1px solid #00FFFF;
    box-shadow: inset 0 0 5px rgba(81, 203, 238, 1);
}
.x-search.active .e_search_icon{
    color: #00FFFF;
    transform: rotate(0deg);
}
/*关闭按钮*/
.x-search .e_search_close{
    position: absolute;
    width: .8rem;
    height: .8rem;
    top: -.08rem;
    right: .3rem;
    font-size: .56rem;
    color: #666666;
    z-index: 9;
    /*transform: rotate(0deg);*/
    transition: all .3s cubic-bezier(0.285, -0.450, 0.935, 0.110) .2s;
}
/*.x-search .e_search_close:hover{
    color: #CCCCCC;
}*/
.x-search.active .e_search_close{
    right: -1.2rem;
    transform: rotate(360deg);
    transition: all .8s cubic-bezier(0.000, 0.105, 0.035, 1.570) .5s;
}
</style>