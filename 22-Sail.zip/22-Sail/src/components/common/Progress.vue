<template>
<div class="x-progress">
    <div class="e_wrapper" :style="{
                height:height+'rem',
                width:label?null:'100%',
                'border-color':color,
                'border-radius':height / 2 + 'rem'
            }">
        <div class="e_percent" ref="progress" :style="{
            color:textColor,
            width:percent+'%',
            height:height+'rem',
            background:color,
            'line-height':height+'rem',
            'border-radius':height / 2 + 'rem'}">{{percent}}%</div>
    </div>
    <div class="e_label" v-if="label"
         :style="{height:height+'rem',
            'line-height':height+'rem'}">{{label}}</div>
</div>
</template>

<script type="text/javascript">
export default {
    props: {
        percent: {
            type: Number,
            default: 0
        },
        color: {
            type: String
        },
        textColor: {
            type: String
        },
        height: {
            type: Number
        },
        label: {
            type: String
        }
    },
    mounted () {
        this.$refs.progress.style.width = '20px'
        setTimeout(() => {
            this.$refs.progress.style.width = this.percent + '%'
        }, 100)
    }
}
</script>

<style type="text/css">
.x-progress{
    margin: .5rem auto;
}
.x-progress .e_wrapper{
    display: inline-block;
    width: calc(100% - 4rem);
    height: 1rem;
    border: 2px solid blue;
    border-radius: .5rem;
}
.x-progress .e_percent{
    margin-top: -2px;
    width: 0.1%;
    height: 1rem;
    line-height: 1rem;
    color: white;
    font-weight: bold;
    text-align: center;
    border-radius: .5rem;
    background-color: blue;
    transition: width 1s ease-in;
}
.x-progress .e_label{
    display: inline-block;
    float: right;
    width: 4rem;
    height: 1rem;
    line-height: 1rem;
    top: 0;
    right: 0;
    text-align: center;
    color: #333333;
    font-size: .56rem;
    font-weight: bold;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
</style>