// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import Axios from 'axios'
import App from './App'
import store from './store'
import router from './router'
import {loader, toast} from './components/Reminder'

// http请求和响应中间件
Axios.interceptors.request.use(
    config => {
        loader({status: 'loading'})
        return config
    },
    error => {
        // Do something width request error
        loader({status: 'success'})
        toast({text: '请求发送失败！！！'})
        return Promise.reject(error)
    }
)
Axios.interceptors.response.use(
    response => {
        // Do something width response edata
        let msg = null
        if (response.data && response.data.msg) {
            msg = response.data.msg
        }
        loader({status: 'success',
            message: msg
        })
        return response
    },
    error => {
        // Do something width response error
        loader({status: 'success'})
        toast({text: '系统响应失败！！！'})
        return Promise.reject(error)
    }
)

Vue.prototype.$http = Axios

// sessionStorage事件处理
// -------刷新后保持当前用户数据最新，并能获取到token--------
const user = JSON.parse(window.sessionStorage.getItem('user')) || {}
if (user._id) {
    Axios.get('/user/' + user._id)
        .then(res => {
            if (res.data.status === 'success') {
                window.sessionStorage.setItem('user', JSON.stringify(res.data.result))
            } else {
                window.sessionStorage.setItem('user', JSON.stringify({}))
                toast({text: '获取用户信息失败'})
            }
        })
}
Vue.prototype.$user = user || {}
Vue.prototype.$http.defaults.headers.common['Authorization'] = 'Bearer ' + window.sessionStorage.getItem('token')

// ------捕获最新的sessionStorage对象-------
const originalSetItem = window.sessionStorage.setItem
window.sessionStorage.setItem = function (key, value) {
    let setItemEvent = new window.Event('setItemEvent')
    setItemEvent.key = key
    setItemEvent.newValue = value
    window.dispatchEvent(setItemEvent)
    originalSetItem.apply(this, arguments)
}
window.addEventListener('setItemEvent', function (e) {
    if (e.key === 'user') {
        Vue.prototype.$user = JSON.parse(e.newValue) || {}
    }
    if (e.key === 'token') {
        Vue.prototype.$http.defaults.headers.common['Authorization'] = 'Bearer ' + e.newValue
    }
})

// 获取requestAnimationFrame异步执行动画
var lastTime = 0
var vendors = ['ms', 'moz', 'webkit', 'o']
for (let x = 0; x < vendors.length && !window.requestAnimationFrame; x++) {
    window.requestAnimationFrame = window[vendors[x] + 'RequestAnimationFrame']
    window.cancelAnimationFrame = window[vendors[x] + 'CancelAnimationFrame'] ||
        window[vendors[x] + 'CancelRequestAnimationFrame']
}
if (!window.requestAnimationFrame) {
    window.requestAnimationFrame = function (callback, element) {
        var curTime = new Date().getTime()
        var timeToCall = Math.max(0, 16 - (curTime - lastTime))
        var id = window.setTimeout(function () {
            callback(curTime + timeToCall)
        }, timeToCall)
        lastTime = curTime + timeToCall
        return id
    }
}
if (!window.cancelAnimationFrame) {
    window.cancelAnimationFrame = function (id) {
        clearTimeout(id)
    }
}

// 判断是否为移动端, 设定全局变量
var isMobile = false
var dev = navigator.userAgent
if (/Android/i.test(dev) ||
    /BlackBerry/i.test(dev) ||
    /IEMobile/i.test(dev) ||
    /AppleWebKit.*Mobile/i.test(dev) ||
    /iPhone|iPad|iPod/i.test(dev)) {
    isMobile = true
}
Vue.prototype.$isMobile = isMobile

// 根据屏幕大小来判断
// if (window.innerWidth > 640) {
//     Vue.prototype.$isMobile = false
// } else {
//     Vue.prototype.$isMobile = true
// }

/* eslint-disable no-new */
new Vue({
    el: '#app',
    store,
    router,
    template: '<App/>',
    components: { App }
})
