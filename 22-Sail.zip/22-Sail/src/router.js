import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

// layout
const Menu = resolve => require(['./components/layout/Menu'], resolve)
const Header = resolve => require(['./components/layout/Header'], resolve)
const Container = resolve => require(['./components/layout/Container'], resolve)

// Login page
const Login = resolve => require(['./_login'], resolve)
// home page
const Home = resolve => require(['./_home'], resolve)
// status page
const Status = resolve => require(['./_status'], resolve)
// major page
const Major = resolve => require(['./_major'], resolve)
// course page
const Course = resolve => require(['./_course'], resolve)
// grade page
const Grade = resolve => require(['./_grade'], resolve)
// field page
const Field = resolve => require(['./_field'], resolve)
// manager page
const Manager = resolve => require(['./_manager'], resolve)
// Love home
const Love = resolve => require(['./_love'], resolve)

const routes = [
    {
        path: '/login',
        components: {
            'header': Login
        }
    },
    {
        path: '/',
        components: {
            'header': Header,
            'menu': Menu,
            'container': Container
        },
        children: [
            {
                path: '/home',
                component: Home
            },
            {
                path: 'status',
                component: Status
            },
            {
                path: 'major',
                component: Major
            },
            {
                path: 'course',
                component: Course
            },
            {
                path: 'grade',
                component: Grade
            },
            {
                path: 'field',
                component: Field
            },
            {
                path: 'system',
                component: Manager
            },
            {
                path: 'love',
                component: Love
            }
        ]
    }
]

const router = new VueRouter({routes})
router.beforeEach((to, from, next) => {
    if (Vue.prototype.$user.position === 'manager') {
        let allow = to.path
        if (allow === '/course' || allow === '/field' || allow === '/system' || allow === '/love') {
            next()
        } else {
            if (allow === '/home') {
                next()
            } else {
                next('/home')
            }
        }
    } else {
        if (Vue.prototype.$user.position === 'teacher' || Vue.prototype.$user.position === 'student') {
            let allow = to.path
            if (allow === '/status' || allow === '/major' || allow === '/course' || allow === '/grade' || allow === '/love') {
                next()
            } else {
                if (allow === '/home') {
                    next()
                } else {
                    next('/home')
                }
            }
        } else {
            if (to.path === '/login') {
                next()
            } else {
                next('/login')
            }
        }
    }
})

export default router
