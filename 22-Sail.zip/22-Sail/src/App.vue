<template>
    <div id="app">
        <div class="g-top">
            <router-view name="header"></router-view>
        </div>
        <div class="g-left">
            <router-view name="menu"></router-view>
        </div>
        <div class="g-right">
            <router-view name="container"></router-view>
        </div>
    </div>
</template>

<style src="./styles/index.less" lang="less"></style>
<style type="text/css">
#app{
    display: flex;
    flex-wrap: wrap;
    align-items: stretch;
    align-content: flex-start;
    height: 100%;
    width: 100%;
}
#app .g-top{
    width: 100%;
    height: 50px;
    text-align: center;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    background-color: #686F79;
}
#app .g-left{
    min-width: .1px;
    height: calc(100% - 50px);
    background-color: #EEF1F6;
}
#app .g-right{
    flex: 1 1 auto;
    width: 100px;
    height: calc(100% - 50px);
    border: 2px solid #686F79;
    border-top: none;
}
</style>
