<template>
    <div class="x-love">
        <x-bunny class="bunny"></x-bunny>
        <x-monkey class="monkey"></x-monkey>
        <x-bubble></x-bubble>
    </div>
</template>

<script type="text/javascript">
import Bunny from '../components/Bunny'
import Monkey from '../components/Monkey'
import Bubble from '../components/canvas/Bubble'

export default {
    components: {
        'x-bunny': Bunny,
        'x-monkey': Monkey,
        'x-bubble': Bubble
    }
}
</script>

<style type="text/css">
.x-love{
    width: 100%;
    height: 100%;
    background: linear-gradient(to top, #0915CD, #5604A7);
}
.x-love .bunny{
    position: absolute;
    bottom: 100px;
    right: calc(50% - 130px);
    z-index: 10;
}
.x-love .monkey{
    position: absolute;
    bottom: 100px;
    left: calc(50% - 130px);
    z-index: 10;
}
.x-love .shadow{
    display: none;
}
</style>