import Axios from 'axios'
import * as types from '../mutation_types'

const state = {
    users: [],
    teachers: [],
    students: []
}

const getters = {
    users: state => state.users,
    teachers: state => state.teachers,
    students: state => state.students
}

const actions = {
    getUserList ({commit}) {
        Axios.get('/userList/all')
            .then(res => {
                if (res.data.status === 'success') {
                    commit(types.GET_USER_LIST, res.data.result)
                }
            })
    },
    getTeacherList ({commit}) {
        Axios.get('/userList/teacher')
            .then(res => {
                if (res.data.status === 'success') {
                    commit(types.GET_TEACHER_LIST, res.data.result)
                }
            })
    },
    getStudentList ({commit}) {
        Axios.get('/userList/student')
            .then(res => {
                if (res.data.status === 'success') {
                    commit(types.GET_STUDENT_LIST, res.data.result)
                }
            })
    },
    addUser ({commit}, info) {
        Axios.post('/user', info)
            .then(res => {
                if (res.data.status === 'success') {
                    commit(types.ADD_USER_INFO, res.data.result)
                }
            })
    },
    updateUser ({commit}, info) {
        Axios.put('/user', info)
            .then(res => {
                if (res.data.status === 'success') {
                    commit(types.UPDATE_USER_INFO, res.data.result)
                }
            })
    },
    deleteUser ({commit}, info) {
        if (Array.isArray(info)) {
            Axios.post('/userList', info)
                .then(res => {
                    if (res.data.status === 'success') {
                        commit(types.DELETE_USER_INFO, info)
                    }
                })
        } else {
            Axios.delete('/user/' + info._id)
                .then(res => {
                    if (res.data.status === 'success') {
                        commit(types.DELETE_USER_INFO, info)
                    }
                })
        }
    }
}

const mutations = {
    [types.GET_USER_LIST] (state, info) {
        state.users = [].concat(info)
        state.users = state.users.reverse()
    },
    [types.GET_TEACHER_LIST] (state, info) {
        state.teachers = [].concat(info)
        state.teachers = state.teachers.reverse()
    },
    [types.GET_STUDENT_LIST] (state, info) {
        state.students = [].concat(info)
        state.students = state.students.reverse()
    },
    [types.ADD_USER_INFO] (state, info) {
        if (info.position === 'teacher') {
            state.teachers.unshift({_id: info._id, name: info.name})
        }
        if (info.position === 'student') {
            state.students.unshift({_id: info._id, name: info.name})
        }
        state.users.unshift(info)
    },
    [types.UPDATE_USER_INFO] (state, info) {
        state.teachers.forEach((item, index) => {
            if (item._id === info._id) {
                state.teachers.splice(index, 1, info)
            }
        })
        // state.students.forEach((item, index) => {
        //     if (item._id === info._id) {
        //         state.students.splice(index, 1, info)
        //     }
        // })
        state.users.forEach((item, index) => {
            if (item._id === info._id) {
                state.users.splice(index, 1, info)
            }
        })
    },
    [types.DELETE_USER_INFO] (state, info) {
        function contains (arr, item) {
            for (let i = 0; i < arr.length; i++) {
                if (arr[i] === item) {
                    return true
                }
            }
        }
        if (Array.isArray(info)) {
            state.teachers = state.teachers.filter(item => {
                return !contains(info, item._id)
            })
            // state.students = state.students.filter(item => {
            //     return !contains(info, item._id)
            // })
            state.users = state.users.filter(item => {
                return !contains(info, item._id)
            })
        } else {
            state.teachers.forEach((item, index) => {
                if (item._id === info._id) {
                    state.teachers.splice(index, 1)
                    return
                }
            })
            // state.students.forEach((item, index) => {
            //     if (item._id === info._id) {
            //         state.students.splice(index, 1)
            //         return
            //     }
            // })
            state.users.forEach((item, index) => {
                if (item._id === info._id) {
                    state.users.splice(index, 1)
                    return
                }
            })
        }
    }
}

export default {
    state,
    getters,
    actions,
    mutations
}
