import Axios from 'axios'
import * as types from '../mutation_types'

const state = {
    news: []
}

const getters = {
    news: state => state.news
}

const actions = {
    getNewsList ({commit}) {
        Axios.get('/news')
            .then(res => {
                if (res.data.status === 'success') {
                    commit(types.GET_NEWS_LIST, res.data.result)
                }
            })
    },
    createNews ({commit}, info) {
        Axios.post('/news', info)
            .then(res => {
                if (res.data.status === 'success') {
                    commit(types.ADD_ONE_NEWS, res.data.result)
                }
            })
    }
}

const mutations = {
    [types.GET_NEWS_LIST] (state, info) {
        state.news = [].concat(info)
    },
    [types.ADD_ONE_NEWS] (state, info) {
        state.news.unshift(info)
    }
}

export default {
    state,
    getters,
    actions,
    mutations
}
