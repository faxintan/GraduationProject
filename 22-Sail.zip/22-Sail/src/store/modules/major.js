import Axios from 'axios'
import * as types from '../mutation_types'

const state = {
    major: {},
    majors: []
}

const getters = {
    major: state => state.major,
    majors: state => state.majors
}

const actions = {
    getMajorList ({commit}) {
        Axios.get('/majorList')
            .then(res => {
                if (res.data.status === 'success') {
                    commit(types.GET_MAJOR_LIST, res.data.result)
                }
            })
    },
    getMajorById ({commit}, id) {
        Axios.get('/major/' + id)
            .then(res => {
                if (res.data.status === 'success') {
                    commit(types.GET_MAJOR_INFO, res.data.result)
                }
            })
    },
    addMajor ({commit}, info) {
        Axios.post('major', info)
            .then(res => {
                if (res.data.status === 'success') {
                    commit(types.ADD_MAJOR_INFO, res.data.result)
                }
            })
    },
    updateMajor ({commit}, info) {
        Axios.put('/major', info)
            .then(res => {
                if (res.data.status === 'success') {
                    commit(types.UPDATE_MAJOR_INFO, res.data.result)
                }
            })
    },
    deleteMajor ({commit}, info) {
        if (Array.isArray(info)) {
            Axios.post('/majorList', info)
                .then(res => {
                    if (res.data.status === 'success') {
                        commit(types.DELETE_MAJOR_INFO, info)
                    }
                })
        } else {
            Axios.delete('/major/' + info._id)
                .then(res => {
                    if (res.data.status === 'success') {
                        commit(types.DELETE_MAJOR_INFO, info)
                    }
                })
        }
    }
}

const mutations = {
    [types.GET_MAJOR_INFO] (state, info) {
        state.major = info
    },
    [types.GET_MAJOR_LIST] (state, info) {
        state.majors = [].concat(info)
        state.majors = state.majors.reverse()
    },
    [types.ADD_MAJOR_INFO] (state, info) {
        state.majors.unshift(info)
    },
    [types.UPDATE_MAJOR_INFO] (state, info) {
        state.majors.forEach((item, index) => {
            if (item._id === info._id) {
                state.majors.splice(index, 1, info)
            }
        })
    },
    [types.DELETE_MAJOR_INFO] (state, info) {
        function contains (arr, item) {
            for (let i = 0; i < arr.length; i++) {
                if (arr[i] === item) {
                    return true
                }
            }
        }
        if (Array.isArray(info)) {
            state.majors = state.majors.filter(item => {
                return !contains(info, item._id)
            })
        } else {
            state.majors.forEach((item, index) => {
                if (item._id === info._id) {
                    state.majors.splice(index, 1)
                    return
                }
            })
        }
    }
}

export default {
    state,
    getters,
    actions,
    mutations
}
