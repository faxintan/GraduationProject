import Axios from 'axios'
import * as types from '../mutation_types'

const state = {
    courses: []
}

const getters = {
    courses: state => state.courses
}

const actions = {
    getCourseList ({commit}) {
        Axios.get('/courseList')
            .then(res => {
                if (res.data.status === 'success') {
                    commit(types.GET_COURSE_LIST, res.data.result)
                }
            })
    },
    addCourse ({commit}, info) {
        Axios.post('/course', info)
            .then(res => {
                if (res.data.status === 'success') {
                    commit(types.ADD_COURSE_INFO, res.data.result)
                }
            })
    },
    updateCourse ({commit}, info) {
        Axios.put('/course', info)
            .then(res => {
                if (res.data.status === 'success') {
                    commit(types.UPDATE_COURSE_INFO, info)
                }
            })
    },
    deleteCourse ({commit}, info) {
        if (Array.isArray(info)) {
            Axios.post('/courseList', info)
                .then(res => {
                    if (res.data.status === 'success') {
                        commit(types.DELETE_COURSE_INFO, info)
                    }
                })
        } else {
            Axios.delete('/course/' + info._id)
                .then(res => {
                    if (res.data.status === 'success') {
                        commit(types.DELETE_COURSE_INFO, info)
                    }
                })
        }
    },
    selectCourses ({commit, state}, info) {
        function contain (arr, item) {
            for (let i = 0; i < arr.length; i++) {
                if (arr[i] === item) {
                    return true
                }
            }
        }
        if (Array.isArray(info.courses)) {
            const selected = state.courses.filter(item => {
                return contain(info.courses, item._id)
            })
            Axios.post('courseSelect', {student: info.student, courses: selected})
                .then(res => {
                    if (res.data.status === 'success') {
                        window.sessionStorage.setItem('user', JSON.stringify(res.data.result))
                    }
                })
        } else {
            Axios.post('courseSelect', info)
                .then(res => {
                    if (res.data.status === 'success') {
                        window.sessionStorage.setItem('user', JSON.stringify(res.data.result))
                    }
                })
        }
    },
    unselectCourses ({commit}, info) {
        if (Array.isArray(info.courses)) {
            Axios.post('courseUnselect', info)
                .then(res => {
                    if (res.data.status === 'success') {
                        window.sessionStorage.setItem('user', JSON.stringify(res.data.result))
                    }
                })
        } else {
            Axios.post('courseUnselect', info)
                .then(res => {
                    if (res.data.status === 'success') {
                        window.sessionStorage.setItem('user', JSON.stringify(res.data.result))
                    }
                })
        }
    }
}

const mutations = {
    [types.GET_COURSE_LIST] (state, info) {
        state.courses = [].concat(info)
        state.courses = state.courses.reverse()
    },
    [types.ADD_COURSE_INFO] (state, info) {
        state.courses.unshift(info)
    },
    [types.UPDATE_COURSE_INFO] (state, info) {
        state.courses.forEach((item, index) => {
            if (item._id === info._id) {
                state.courses.splice(index, 1, info)
            }
        })
    },
    [types.DELETE_COURSE_INFO] (state, info) {
        function contain (arr, item) {
            for (let i = 0; i < arr.length; i++) {
                if (arr[i] === item) {
                    return true
                }
            }
        }
        if (Array.isArray(info)) {
            state.courses = state.courses.filter(item => {
                return !contain(info, item._id)
            })
        } else {
            state.courses.forEach((item, index) => {
                if (item._id === info._id) {
                    state.courses.splice(index, 1)
                    return
                }
            })
        }
    }
}

export default {
    state,
    getters,
    actions,
    mutations
}
