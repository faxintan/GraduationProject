// 用户信息
export const GET_USER_LIST = 'GET_USER_LIST'
export const GET_TEACHER_LIST = 'GET_TEACHER_LIST'
export const GET_STUDENT_LIST = 'GET_STUDENT_LIST'
export const ADD_USER_INFO = 'ADD_USER_INFO'
export const UPDATE_USER_INFO = 'UPDATE_USER_INFO'
export const DELETE_USER_INFO = 'DELETE_USER_INFO'

// 学校消息列表
export const GET_NEWS_LIST = 'GET_NEWS_LIST'
export const ADD_ONE_NEWS = 'ADD_ONE_NEWS'

// 专业信息
export const GET_MAJOR_INFO = 'GET_MAJOR_INFO'
export const GET_MAJOR_LIST = 'GET_MAJOR_LIST'
export const ADD_MAJOR_INFO = 'ADD_MAJOR_INFO'
export const UPDATE_MAJOR_INFO = 'UPDATE_MAJOR_INFO'
export const DELETE_MAJOR_INFO = 'DELETE_MAJOR_INFO'

// 课程信息
export const GET_COURSE_LIST = 'GET_COURSE_LIST'
export const ADD_COURSE_INFO = 'ADD_COURSE_INFO'
export const UPDATE_COURSE_INFO = 'UPDATE_COURSE_INFO'
export const DELETE_COURSE_INFO = 'DELETE_COURSE_INFO'
