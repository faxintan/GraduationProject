import Vue from 'vue'
import Vuex from 'vuex'

import user from './modules/user'
import news from './modules/news'
import major from './modules/major'
import course from './modules/course'

Vue.use(Vuex)

const debug = process.env.NODE_ENV !== 'production'

export default new Vuex.Store({
    modules: {
        user,
        news,
        major,
        course
    },
    strict: debug
})
