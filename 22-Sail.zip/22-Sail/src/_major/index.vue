<template>
<div class="x-major">
    <div class="row">
        <div class="rank">{{major.score}}
            <span>专业评分</span>
        </div>
        <div class="description">
            <div class="pictrue"></div>
            <div class="details">
                <div class="title m_small">{{major.name}}</div>
                <div class="more">{{major.intro}}</div>
            </div>
        </div>
    </div>
    <div class="row" :style="{height:$isMobile?'10rem':'15rem','padding-top':'3rem'}">
        <div class="theme">2000 ~ 2010 年本专业学生总数</div>
        <x-linechart :config="{rows:5,incre:50,init:100,color:'#34C0E3'}"
            :data="new Array({x:'2010',y:230},
                    {x:'2011',y:320},
                    {x:'2012',y:250},
                    {x:'2013',y:230},
                    {x:'2014',y:280},
                    {x:'2015',y:300},
                    {x:'2016',y:270},
                    {x:'2017',y:310})"></x-linechart>
    </div>
    <div class="row">
        <div class="data" :style="{width:$isMobile?'100%':'50%'}">
            <div class="theme">2017就业率</div>
            <x-piechart :config="{outter:30,type:'circle'}"
                        :data="[{label: '专业对口就业', value: 55, color: '#72B8FB'},
                        {label: '转行就业', value: 30, color: '#89EB78'},
                        {label: '延缓就业', value: 10, color: '#FBC262'},
                        {label: '暂未就业', value: 5, color: '#CCCCCC'}]"></x-piechart>
        </div>
        <div class="data clearfix" :style="{width:$isMobile?'100%':'50%',float:'right','padding-top':'2.5rem'}">
            <div class="theme">薪资范围</div>
            <x-progress :percent="15"
                        :label="'15k以上'"
                        :color="'#72B8FB'"></x-progress>
            <x-progress :percent="20"
                        :label="'11k~15k'"
                        :color="'#89EB78'"></x-progress>
            <x-progress :percent="45"
                        :label="'8k~11k'"
                        :color="'#FBC262'"></x-progress>
            <x-progress :percent="10"
                        :label="'5k~8k'"
                        :color="'#EC5747'"></x-progress>
            <x-progress :percent="10"
                        :label="'5k以下'"
                        :color="'#CCCCCC'"></x-progress>
        </div>
    </div>
</div>
</template>

<script type="text/javascript">
import {mapGetters, mapActions} from 'vuex'
import Progress from '../components/common/Progress'
import PieChart from '../components/canvas/PieChart'
import LineChart from '../components/canvas/LineChart'

export default {
    computed: {
        ...mapGetters({major: 'major'})
    },
    methods: {
        ...mapActions(['getMajorById'])
    },
    components: {
        'x-progress': Progress,
        'x-piechart': PieChart,
        'x-linechart': LineChart
    },
    mounted () {
        if (this.$user && this.$user.major) {
            this.getMajorById(this.$user.major)
        }
    }
}
</script>

<style type="text/css">
</style>
<style type="text/css">
.x-major{
    margin: .4rem;
    height: auto;
    min-height: 100%;
    border: 1px solid #EEEEEE;
    background-color: #FFFFFF;
}
.x-major .row{
    position: relative;
    width: 100%;
    border-bottom: 1px solid #EEEEEE;
    overflow: hidden;
}
.x-major .row:last-child{
    border: none;
}
.x-major .description{
    width: calc(100% - 4rem);
    height: 4rem;
}
.x-major .pictrue{
    display: inline-block;
    margin: .5rem;
    width: 3rem;
    height: 3rem;
    border-radius: 50%;
    border: 1px solid #EAEAEA;
    background: url('../assets/logo.png') center no-repeat,
                linear-gradient(to bottom, white 45%, #2CB0E6);
    background-size: contain;
    background-color: #EEEEEE;
}
.x-major .details{
    display: inline-block;
    width: calc(100% - 5rem);
    vertical-align: top;
}
.x-major .title{
    margin: .8rem 0 .4rem;
    font-size: .64rem;
    font-weight: bold;
    color: #666666;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.x-major .more{
    color: #999999;
    font-size: .48rem;
}
.x-major .rank{
    position: relative;
    margin: .5rem 0;
    display: inline-block;
    float: right;
    width: 4rem;
    height: 3rem;
    line-height: 2.5rem;
    font-size: 1.5rem;
    text-align: center;
    border-left: 1px solid #EEEEEE;
}
.x-major .rank span{
    position: absolute;
    display: block;
    width: 100%;
    bottom: -.8rem;
    font-size: .48rem;
    color: #CCCCCC;
}
.x-major .theme{
    position: absolute;
    width: 100%;
    height: 1.5rem;
    line-height: 1.5rem;
    top: 1rem;
    text-align: center;
    font-size: .64rem;
    color: #FFFFFF;
    background-color: #EEEEEE;
    border-bottom: 1.5rem solid #B2EDFC;
    border-left: 1.5rem solid transparent;
    border-right: 1.5rem solid #B2EDFC;
}
.x-major .data{
    position: relative;
    display: inline-block;
    padding-top: 3rem;
    height: 11rem;
    overflow: hidden;
}
</style>