<template>
    <div class="x-manager">
        <div class="wrapper">
            <div class="top">
                <x-search style="margin-right:1.2rem;" v-model="search.text"></x-search>
                <x-select v-model="search.type" :options="Object.assign({all: '全部'},position)"></x-select>
                <div class="manage" v-if="true">
                    <div class="x-btn blue" @click="showDataCard(false)">添加账号</div>
                    <div class="x-btn m_hide" @click="delAccount(true)">删除账号</div>
                </div>
            </div>
            <div class="x-container">
                <div class="row title">
                    <div class="col1 m_hide"></div>
                    <div class="col5"></div>
                    <div class="col2 m_hide">职位</div>
                    <div class="col2">账号</div>
                    <div class="col3">密码</div>
                    <div class="col4 m_hide">联系方式</div>
                </div>
            </div>
            <div class="x-container m_small" style="min-height:9rem;">
                <div class="row content" v-for="(user, index) in users"
                     @click="showDataCard(user)">
                    <div class="col1 m_hide" @click.stop>
                        <input class="x-checkbox" style="margin-left:.3rem;"
                               type="checkbox"
                               v-model="selected"
                               :value="user._id"/>
                    </div>
                    <div class="col5">
                        <div class="photo"></div>
                        <div class="detail">
                            <div class="name">{{user.name}}<span v-if="user.name==='谭发新'||user.name==='陈淑仪'">VIP</span></div>
                            <div class="description">{{user.briefIntro || '个人简介信息'}}</div>
                        </div>
                    </div>
                    <div class="col2 m_hide">{{position[user.position]}}</div>
                    <div class="col2">{{user.account}}</div>
                    <div class="col3">{{user.password}}</div>
                    <div class="col4 m_hide contact">
                        <div><span class="icon-mobile"></span> {{user.phone}}</div>
                        <div><span class="icon-envelop"></span> {{user.email}}</div>
                    </div>
                </div>
            </div>
            <div class="row-title">推送消息</div>
            <div class="x-textarea" style="margin-top:1.5rem;">
                <div class="e_content" contenteditable="true" ref="news"
                     @blur="getMessage"></div>
                <input class="e_title" type="text" placeholder="输入标题" v-model="news.title">
            </div>
            <div style="text-align:right;">
                <x-select v-model="news.type"
                    :options="{school:'学校公告',award:'奖励通告',user:'用户消息'}"></x-select>
                <div class="x-btn blue" @click="postMessage">提交</div>
            </div>
        </div>
        <x-datacard v-model="showCard" :title="'账号信息'"
                :yes="add?'添加账号':'保存更改'"
                :no="add?'取消':'删除账号'"
                @confirm="addOrUpdate"
                @cancel="delAccount(false)">
            <div class="x-container">
                <div class="row wrap">
                    <div class="col1 m_hide"></div>
                    <div class="col7 m_expand">
                        <x-input v-model="user.name">姓名</x-input>
                    </div>
                    <div class="col7 m_expand m_first" style="overflow:visible;text-align:center;">
                        <x-select v-model="user.position" style="width:100%;"
                            :options="Object.assign({label:'请选择职位'},position)">
                        </x-select>
                    </div>
                    <div class="col1 m_hide"></div>
                    <div class="col1 m_hide"></div>
                    <div class="col7 m_expand">
                        <x-input v-model="user.account">账号</x-input>
                    </div>
                    <div class="col7 m_expand">
                        <x-input v-model="user.password">密码</x-input>
                    </div>
                    <div class="col1 m_hide"></div>
                    <div class="col1 m_hide"></div>
                    <div class="col7 m_expand">
                        <x-input :type="'number'" v-model="user.phone">电话</x-input>
                    </div>
                    <div class="col7 m_expand">
                        <x-input v-model="user.email">Email</x-input>
                    </div>
                    <div class="col1 m_hide"></div>
                </div>
            </div>
        </x-datacard>
    </div>
</template>

<script type="text/javascript">
import md5 from 'md5'
import {mapGetters, mapActions} from 'vuex'
import {toast} from '../components/Reminder'
import Input from '../components/form/Input2'
import Select from '../components/common/Select'
import Search from '../components/common/Search'
import DataCard from '../components/common/DataCard'

export default {
    data () {
        return {
            add: false,
            old: {},
            user: {},
            selected: [],
            showCard: false,
            search: {text: '', type: 'all'},
            news: {title: '', type: 'school', content: ''}
        }
    },
    computed: {
        ...mapGetters({data: 'users'}),
        users () {
            const search = this.search
            return this.data.filter(item => {
                return (item.position === search.type || search.type === 'all') &&
                        (item.name.match(search.text) || search.text === '')
            })
        },
        position () {
            return {student: '学生', teacher: '老师', manager: '管理员'}
        }
    },
    methods: {
        ...mapActions([
            'addUser',
            'updateUser',
            'deleteUser',
            'getUserList',
            'createNews']),
        showDataCard (user) {
            if (user) {
                this.add = false
                this.old = Object.assign({}, user)
                this.user = Object.assign({}, user)
            } else {
                this.add = true
                this.user = {}
            }
            this.showCard = true
        },
        addOrUpdate () {
            let user = this.user
            if (this.add) {
                if (!user.name) {
                    toast({text: '请输入用户姓名'})
                    return
                }
                if (!user.position) {
                    toast({text: '请选择职位'})
                    return
                }
                if (!user.account) {
                    toast({text: '请输入用户账号'})
                    return
                }
                if (!user.password) {
                    toast({text: '请输入账号密码'})
                    return
                }
                if (!user.phone) {
                    toast({text: '请输入用户联系电话'})
                    return
                }
                if (!user.email) {
                    toast({text: '请输入用户联系邮箱'})
                    return
                }
                user.password = md5(user.password)
                this.addUser(user)
            } else {
                // 用户重置密码
                let old = this.old
                if (this.$user.name !== '谭发新' && this.$user.account !== 'admin') {
                    if (old.name === '陈淑仪' || old.name === '谭发新' || old.account === 'admin') {
                        toast({text: '重要用户信息，您无权更改该信息！！！'})
                        return
                    }
                }
                if (user.password && user.password.length < 16) {
                    user.password = md5(user.password)
                } else {
                    if (user.password && user.password.length !== 32) {
                        toast({text: '密码不能超过16位数'})
                        return
                    }
                }
                if (this.old.position !== user.position) {
                    toast({text: '不支持更改职位'})
                    return
                }
                this.updateUser(user)
            }
            this.old = {}
            this.user = {}
            this.showCard = false
        },
        delAccount (multi) {
            if (multi) {
                if (this.$user.name !== '谭发新' && this.$user.account !== 'admin') {
                    let selected = this.selected
                    let len = selected.length
                    for (let i = 0; i < len; i++) {
                        this.data.forEach(item => {
                            if (selected[i] === item._id && (item.name === '陈淑仪' || item.name === '谭发新' || item.account === 'admin')) {
                                selected.splice(i, 1)
                            }
                        })
                    }
                }
                if (this.selected.length) {
                    this.deleteUser(this.selected)
                    this.selected = []
                } else {
                    toast({text: '请先选择需要删除的账号'})
                }
            } else {
                let old = this.old
                if (this.$user.name !== '谭发新' && this.$user.account !== 'admin') {
                    if (old.name === '陈淑仪' || old.name === '谭发新' || old.account === 'admin') {
                        toast({text: '重要用户信息，您无权删除！！！'})
                        return
                    }
                }
                this.deleteUser(this.user)
                this.user = {}
                this.showCard = false
            }
        },
        getMessage (e) {
            this.news.content = e.target.innerText
        },
        postMessage () {
            this.createNews(Object.assign({}, this.news))
            this.$refs.news.innerText = ''
            this.news.content = ''
            this.news.title = ''
        }
    },
    components: {
        'x-input': Input,
        'x-datacard': DataCard,
        'x-select': Select,
        'x-search': Search
    },
    created () {
        if (this.data && !this.data.length) {
            this.getUserList()
        }
    }
}
</script>

<style type="text/css">
.x-manager{
    width: 100%;
    height: 100%;
}
.x-manager .wrapper{
    padding: .5rem;
}
.x-manager .row-title{
    padding-left: .4rem;
    margin: 1.2rem .1rem -.8rem;
    height: .56rem;
    line-height: .6rem;
    font-size: .64rem;
    border-left: .2rem solid #fc923f;
}
.x-manager .top{
    margin-bottom: .4rem;
    min-height: 1.5rem;
    line-height: 1.5rem;
}
.x-manager .manage{
    display: inline-block;
    float: right;
}
.x-manager .title{
    font-weight: bold;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    background-color: #CCCCCC;
}
.x-manager .content{
    margin-top: .4rem;
    border-radius: .2rem;
    background-color: #FFFFFF;
}
.x-manager .content:hover{
    border: 1px solid #00FFFF;
    box-shadow: inset 0 0 10px rgba(0, 255, 255, .7);
}
.x-manager .photo{
    float: left;
    width: 2rem;
    height: 2rem;
    border-radius: 50%;
    background: url('../assets/logo.png') center no-repeat;
    background-color: #EAEAEA;
    background-size: contain;
}
.x-manager .detail{
    margin-left: 2.3rem;
    height: 2rem;
}
.x-manager .name{
    height: 1.2rem;
    line-height: 1.6rem;
    font-size: .56rem;
}
.x-manager .name span{
    margin-left: .2rem;
    font-size: .48rem;
    font-weight: bolder;
    font-style: oblique;
    color: yellow;
}
.x-manager .description{
    font-size: .48rem;
    color: #999999;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.x-manager .contact span{
    display: inline-block;
    margin: .2rem;
    color: #00FFFF;
}
.x-manager .item{
    width: 40%;
    height: 1rem;
    line-height: 1rem;
    font-size: .56rem;
    text-align: left;
}
.x-manager .item span{
    color: #333333;
    font-weight: bold;
    letter-spacing: 1px;
}
</style>