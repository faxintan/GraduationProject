<template>
    <div class="x-grade">
        <div class="wrapper">
            <div class="top">
                <x-search :style="{'margin-right':'1.2rem'}" v-model="search.text"></x-search>
                <x-select v-model="search.type"
                    :options="{all:'全部',pass:'已通过',progress:'进行中',resume:'需重修'}"></x-select>
            </div>
            <div class="x-container">
                <div class="row title">
                    <div class="col5">课程信息</div>
                    <div class="col5 m_hide center">完成进度</div>
                    <div class="col1 center">学分</div>
                    <div class="col2 center">成绩</div>
                    <div class="col1 center">排名</div>
                    <div class="col3 m_hide center">课程时间</div>
                </div>
            </div>
            <div class="x-container">
                <div class="row content" v-for="(c, index) in $user.courses" @click="checkDetail(c, index)">
                    <div class="col5">
                        <div class="photo"></div>
                        <div class="detail">
                            <div class="name">{{c.name}}</div>
                            <div class="description">{{c.intro}}</div>
                        </div>
                    </div>
                    <div class="col5 m_hide">
                        <x-progress :percent="progress[index]" :color="'#7EF289'"></x-progress>
                    </div>
                    <div class="col1 center">{{c.credit}}</div>
                    <div class="col2 center">{{c.score||'？'}}</div>
                    <div class="col1 center">？</div>
                    <div class="col3 m_small m_hide center" style="overflow:visible;">
                        <div class="time"><span class="icon-calendar"></span>{{c.beginDate}}</div>
                        <div class="time"><span class="icon-calendar"></span>{{c.endDate}}</div>
                    </div>
                </div>
            </div>
        </div>
        <x-datacard v-model="dataCard" :title="$user.position==='student'?'课程成绩':'录入课程成绩'"
                :yes="'确定'"
                :no="$user.position==='student'?'联系老师':'取消'"
                @confirm="confirm"
                @cancel="cancel">
            <div class="x-container">
                <div class="row wrap">
                    <div class="col1"></div>
                    <div class="col6 item" v-if="$user.position==='student'"><span>成绩:&nbsp;</span>
                        <span style="color:#FD5B5B;">{{course.score||'？？？'}}</span>
                    </div>
                    <div class="col6" v-else>
                        <x-input :type="'number'" v-model="data.score">评分:</x-input>
                    </div>
                    <div class="col2"></div>
                    <div class="col6 item" v-if="$user.position==='student'"><span>学分:&nbsp;</span>{{course.credit}}</div>
                    <div class="col6" style="overflow:visible;" v-else>
                        <x-select style="width:100%" v-model="data.studentId"
                            :options="Object.assign({label:'请选择学生'},students)"></x-select>
                    </div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                    <div class="col6 item"><span>名称: </span>{{course.name}}</div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                    <div class="col6 item"><span>类别: </span>{{fields[course.field]}}</div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                    <div class="col6 item"><span>完成进度: </span>{{progress[course.index]}}%</div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                    <div class="col6 item"><span>班级排名: </span>&nbsp;？</div>
                    <div class="col1"></div>
                    <div class="col1"></div>
                </div>
            </div>
        </x-datacard>
    </div>
</template>

<script type="text/javascript">
import Input from '../components/form/Input2'
import Select from '../components/common/Select'
import Search from '../components/common/Search'
import Progress from '../components/common/Progress'
import DataCard from '../components/common/DataCard'

export default {
    data () {
        return {
            data: {},
            course: {},
            students: {},
            search: {text: '', type: 'all'},
            dataCard: false
        }
    },
    computed: {
        progress () {
            let prog = []
            let now = Date.now()
            let courses = this.$user.courses
            if (Array.isArray(courses)) {
                courses.forEach(item => {
                    let begin = Date.parse(item.beginDate)
                    let end = Date.parse(item.endDate)
                    if (now > begin && now < end) {
                        prog.push(Math.ceil((now - begin) / (end - begin) * 100))
                    } else {
                        prog.push(0)
                    }
                })
            }
            return prog
        },
        fields () {
            return {techno: '计算机科学', front: '前端技术', basic: '公共基础'}
        }
    },
    methods: {
        checkDetail (course, index) {
            var vm = this
            this.$http.get('/courseStudents/' + this.$user.courses[index]._id)
                .then(res => {
                    if (res.data.status === 'success') {
                        let s = {}
                        let temp = res.data.result
                        if (Array.isArray(temp)) {
                            temp.forEach(item => {
                                s[item._id] = item.name
                            })
                        }
                        vm.students = Object.assign({}, s)
                    }
                })
            this.course = course
            this.course.index = index
            this.dataCard = true
        },
        confirm () {
            if (this.$user.position === 'teacher') {
                let data = Object.assign({courseId: this.course._id}, this.data)
                this.$http.post('/courseScore', data)
                this.data = {}
            }
            this.dataCard = false
            this.course = {}
        },
        cancel () {
            this.dataCard = false
        }
    },
    components: {
        'x-input': Input,
        'x-select': Select,
        'x-search': Search,
        'x-datacard': DataCard,
        'x-progress': Progress
    }
}
</script>

<style type="text/css">
.x-grade{
    width: 100%;
    height: 100%;
}
.x-grade .wrapper{
    padding: .5rem;
}
.x-grade .top{
    margin-bottom: .4rem;
    min-height: 1.5rem;
    line-height: 1.5rem;
}
.x-grade .manage{
    display: inline-block;
    float: right;
}
.x-grade .title{
    font-weight: bold;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    background-color: #CCCCCC;
}
.x-grade .content{
    margin-top: .4rem;
    border-radius: .2rem;
    background-color: #FFFFFF;
}
.x-grade .content:hover{
    border: 1px solid #00FFFF;
    box-shadow: inset 0 0 10px rgba(0, 255, 255, .7);
}
.x-grade .photo{
    float: left;
    width: 2rem;
    height: 2rem;
    border-radius: 50%;
    background: url('../assets/logo.png') center no-repeat;
    background-color: #EAEAEA;
    background-size: contain;
}
.x-grade .detail{
    margin-left: 2.3rem;
    height: 2rem;
}
.x-grade .name{
    padding: .2rem 0;
}
.x-grade .description{
    font-size: .48rem;
    color: #999999;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.x-grade .center{
    text-align: center;
}
.x-grade .item{
    height: 1.5rem;
    line-height: 1rem;
    font-size: .56rem;
    text-align: left;
    border-bottom: 1px solid #CCCCCC;
}
.x-grade .item span{
    color: #333333;
    font-weight: bold;
    letter-spacing: 1px;
}
.x-grade .time{
    height: 1rem;
    line-height: 1rem;
    font-size: .56rem;
    color: #00FFFF;
}
.x-grade .time span{
    margin-right: .2rem;
    font-size: .64rem;
}
</style>