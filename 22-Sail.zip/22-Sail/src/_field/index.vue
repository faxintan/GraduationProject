<template>
    <div class="x-manager">
        <div class="wrapper">
            <div class="top">
                <x-search style="margin-right:1.2rem;" v-model="search.text"></x-search>
                <x-select v-model="search.type" :options="Object.assign({all: '全部'},teachers)"></x-select>
                <div class="manage" v-if="true">
                    <div class="x-btn blue" @click="showDataCard(false)">添加专业</div>
                    <div class="x-btn m_hide" @click="delMajor(true)">删除专业</div>
                </div>
            </div>
            <div class="x-container">
                <div class="row title">
                    <div class="col1 m_hide"></div>
                    <div class="col3">专业名称</div>
                    <div class="col5 m_hide">介绍</div>
                    <div class="col2 center">班主任</div>
                    <div class="col1 m_hide">评分</div>
                    <div class="col4">联系方式</div>
                </div>
            </div>
            <div class="x-container m_small" style="min-height:9rem;">
                <div class="row content" v-for="(major, index) in majors"
                     @click="showDataCard(major)">
                    <div class="col1 m_hide" @click.stop>
                        <input class="x-checkbox" style="margin-left:.3rem;"
                               type="checkbox"
                               v-model="selected"
                               :value="major._id"/>
                    </div>
                    <div class="col3">
                        <div class="photo"></div>
                        <div class="detail">
                            <div class="name">{{major.name}}</div>
                            <div class="description">more details</div>
                        </div>
                    </div>
                    <div class="col5 m_hide" style="white-space:pre-wrap;max-height:2rem;overflow-y:scroll;">{{major.intro}}</div>
                    <div class="col2 center">{{teachers[major.teacher]}}</div>
                    <div class="col1 m_hide">{{major.score}}</div>
                    <div class="col4 contact">
                        <div><span class="icon-mobile"></span> {{major.phone}}</div>
                        <div><span class="icon-envelop"></span> {{major.email}}</div>
                    </div>
                </div>
            </div>
        </div>
        <x-datacard v-model="showCard" :title="'专业信息'"
                :yes="add?'添加专业':'保存更改'"
                :no="add?'取消':'删除专业'"
                @confirm="addOrUpdateMajor"
                @cancel="delMajor(false)">
            <div class="x-container">
                <div class="row  m_wrap" style="overflow: visible;">
                    <div class="col1 m_hide"></div>
                    <div class="col7 m_expand m_last">
                        <x-input v-model="major.name">专业</x-input>
                    </div>
                    <div class="col7 m_expand m_first" style="overflow:visible;text-align:center;">
                        <x-select v-model="major.teacher" style="width: 100%;"
                            :options="Object.assign({label: '请选择班主任'}, teachers)">
                        </x-select>
                    </div>
                    <div class="col1 m_hide"></div>
                </div>
                <div class="row wrap">
                    <div class="col1 m_hide"></div>
                    <div class="col7 m_expand">
                        <x-input v-model="major.subject">学科</x-input>
                    </div>
                    <div class="col7 m_expand">
                        <x-input :type="'number'" v-model="major.score">评分</x-input>
                    </div>
                    <div class="col1 m_hide"></div>
                    <div class="col1 m_hide"></div>
                    <div class="col7 m_expand">
                        <x-input :type="'number'" v-model="major.phone">电话</x-input>
                    </div>
                    <div class="col7 m_expand">
                        <x-input v-model="major.email">Email</x-input>
                    </div>
                    <div class="col1 m_hide"></div>
                    <div class="col1 m_hide"></div>
                    <div class="col14">
                        <div class="x-textarea">
                            <div class="e_content" contenteditable="true" @blur="getIntroduction">{{major.intro}}</div>
                            <label class="e_title" type="text">专业介绍</label>
                        </div>
                    </div>
                    <div class="col1 m_hide"></div>
                </div>
            </div>
        </x-datacard>
    </div>
</template>

<script type="text/javascript">
import {mapGetters, mapActions} from 'vuex'
import {toast} from '../components/Reminder'
import Input from '../components/form/Input2'
import Select from '../components/common/Select'
import Search from '../components/common/Search'
import DataCard from '../components/common/DataCard'

export default {
    data () {
        return {
            search: {text: '', type: 'all'},
            add: false,
            major: {},
            selected: [],
            showCard: false
        }
    },
    computed: {
        ...mapGetters({
            mList: 'majors',
            tList: 'teachers'
        }),
        teachers () {
            let temp = {}
            this.tList.forEach(item => {
                temp[item._id] = item.name
            })
            return temp
        },
        majors () {
            const search = this.search
            return this.mList.filter(item => {
                return (item.teacher === search.type || search.type === 'all') &&
                        (item.name.match(search.text) || search.text === '')
            })
        }
    },
    methods: {
        ...mapActions(['getTeacherList', 'getMajorList', 'addMajor', 'updateMajor', 'deleteMajor']),
        showDataCard (major) {
            if (major && major._id) {
                this.add = false
                this.major = Object.assign({}, major)
            } else {
                this.add = true
                this.major = {}
            }
            this.showCard = true
        },
        getIntroduction (e) {
            this.major.intro = e.target.innerText
        },
        addOrUpdateMajor () {
            if (this.add) {
                let major = this.major
                if (!major.name) {
                    toast({text: '请输入 专业名称'})
                    return
                }
                if (!major.teacher) {
                    toast({text: '请选择 专业班主任'})
                    return
                }
                if (!major.subject) {
                    toast({text: '请输入 专业学科'})
                    return
                }
                if (!major.score) {
                    toast({text: '请输入 专业评分'})
                    return
                }
                if (!major.phone) {
                    toast({text: '请输入 专业联系电话'})
                    return
                }
                if (!major.email) {
                    toast({text: '请输入 专业联系邮箱'})
                    return
                }
                if (!major.intro) {
                    toast({text: '请输入 专业介绍'})
                    return
                }
                this.addMajor(this.major)
            } else {
                this.updateMajor(this.major)
            }
            this.major = {}
            this.showCard = false
        },
        delMajor (multi) {
            if (multi) {
                if (this.selected.length) {
                    this.deleteMajor(this.selected)
                    this.selected = []
                } else {
                    toast({text: '请先选择需要删除的专业'})
                }
            } else {
                this.deleteMajor(this.major)
                this.showCard = false
            }
        }
    },
    components: {
        'x-input': Input,
        'x-datacard': DataCard,
        'x-select': Select,
        'x-search': Search
    },
    mounted () {
        if (this.tList && !this.tList.length) {
            this.getTeacherList()
        }
        if (this.mList && !this.mList.length) {
            this.getMajorList()
        }
    }
}
</script>

<style type="text/css">
.x-manager{
    width: 100%;
    height: 100%;
}
.x-manager .wrapper{
    padding: .5rem;
}
.x-manager .top{
    margin-bottom: .4rem;
    min-height: 1.5rem;
    line-height: 1.5rem;
}
.x-manager .manage{
    display: inline-block;
    float: right;
}
.x-manager .title{
    font-weight: bold;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    background-color: #CCCCCC;
}
.x-manager .content{
    margin-top: .4rem;
    border-radius: .2rem;
    background-color: #FFFFFF;
}
.x-manager .content:hover{
    border: 1px solid #00FFFF;
    box-shadow: inset 0 0 10px rgba(0, 255, 255, .7);
}
.x-manager .center{
    text-align: center;
}
.x-manager .photo{
    float: left;
    width: 2rem;
    height: 2rem;
    border-radius: 50%;
    background: url('../assets/logo.png') center no-repeat;
    background-color: #EAEAEA;
    background-size: contain;
}
.x-manager .detail{
    margin-left: 2.3rem;
    height: 2rem;
}
.x-manager .name{
    height: 1.2rem;
    line-height: 1.6rem;
    font-size: .56rem;
}
.x-manager .description{
    font-size: .48rem;
    color: #999999;
}
.x-manager .contact span{
    display: inline-block;
    margin: .2rem;
    color: #00FFFF;
}
.x-manager .item{
    width: 40%;
    height: 1rem;
    line-height: 1rem;
    font-size: .56rem;
    text-align: left;
}
.x-manager .item span{
    color: #333333;
    font-weight: bold;
    letter-spacing: 1px;
}
</style>