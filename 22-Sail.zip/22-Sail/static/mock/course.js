{
    "errorCode": 0,
    "errorMessage": "成功",
    "data": [
        {"id": 1, "coNo": "No1", "name": "计算机", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No2", "name": "高数", "field": "公共课", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No3", "name": "物理", "field": "公共课", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No4", "name": "化学", "field": "公共课", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No5", "name": "Java", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No6", "name": "JS", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No7", "name": "HTML", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No8", "name": "CSS", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No9", "name": "Vue", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No10", "name": "Node", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No11", "name": "Mongo", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No12", "name": "Axios", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No13", "name": "Router", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No14", "name": "Vuex", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No15", "name": "数据结构", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No16", "name": "设计模式", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No17", "name": "SQL", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No18", "name": "python", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"},
        {"id": 1, "coNo": "No19", "name": "其他", "field": "科学技术", "GPA": 2, "beginDate": "2017.04", "endDate": "2017.06", "teachers": "老师ID", "students": "学生ID"}
    ]
}